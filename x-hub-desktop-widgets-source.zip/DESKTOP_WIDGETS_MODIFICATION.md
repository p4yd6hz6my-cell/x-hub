# x-hub 桌面日程 / 待办组件改造说明

此副本是在原 x-hub 源码基础上增加桌面双周日程组件、待办组件布局配置及便携打包脚本。它仍是源码版本，不是已验证的 Windows EXE。

## 主要改动

- 新增 `calendar-float` 双周日历窗口：周一开始显示今天所在周及下一周，共 14 天；右键日期可创建日程或待办。
- 日程条目和类别保存在 `data/desktop_widgets.json`，支持类别名称、颜色、背景颜色/透明度、字体与文字颜色设置。
- 桌面待办窗口复用 x-hub 原有 SQLite 待办数据；可以直接勾选，显示全部未完成事项及最近完成的两条。
- 托盘菜单和悬浮球菜单增加日程组件、待办组件的显隐及统一设置入口。
- 两个组件分别保存位置、尺寸和锁定状态；共享外观配置。
- 新增 `scripts/build-portable.ps1`，用于在 Windows 构建并打包便携版。

## 便携版数据结构

发布包根目录应为：

```text
x-hub-portable/
├── x-hub.exe
├── portable                 # 空标记文件，启用便携模式
└── data/
    ├── README.txt
    ├── app.db               # 待办、笔记等 SQLite 数据
    ├── app.json             # 应用配置
    ├── desktop_widgets.json # 双周日历、类别、样式、位置/尺寸/锁定状态
    └── ...                  # 图标、笔记图片、日志等本地文件
```

初次启动后，数据目录会自动初始化。迁移到另一台电脑前，先完全退出 x-hub，再复制整个文件夹（含 `portable` 和 `data`），不要只复制 EXE。应用中由 Windows 凭据管理器/系统密钥链管理的敏感凭据，以及 WebView2 自身缓存不属于可随身迁移的业务数据文件。

## Windows 构建

在 Windows 10/11 x64 开发机上准备 Node.js 24、Rust stable、Microsoft C++ Build Tools 和 Tauri 所需的系统组件，然后在 PowerShell 7 中于项目根目录运行：

```powershell
pwsh -ExecutionPolicy Bypass -File .\scripts\build-portable.ps1
```

输出 ZIP 位于 `dist-portable\x-hub-<版本>-win-x64-portable.zip`。

## 当前验证范围与已知限制

- 已对 Cargo TOML、Tauri JSON 等配置文件执行语法解析，并检查源码改动与便携数据路径。
- 当前执行环境没有 Rust/Cargo、PowerShell，且前端依赖安装未能完成，所以此处没有成功运行 `vue-tsc`、Vite 构建或 Cargo 编译；没有生成或实测 EXE。
- Windows 桌面层级目前使用 `HWND_BOTTOM` 作为尽量压到普通窗口后方的策略。不同 Windows 11 版本、Explorer 桌面宿主、显示器缩放和唤焦点行为需要在实际 Windows 机器上验证；不能仅凭静态检查保证与壁纸层完全一致。
- 日程条目保存在 `desktop_widgets.json`，待办继续保存在 `app.db`。两个组件共享待办库，但“日程事件”与“待办”的数据模型仍然分开。
