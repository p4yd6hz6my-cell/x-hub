//! Desktop calendar / todo widgets.
//!
//! The widget configuration and calendar entries live under paths::data_root(), so a
//! portable build keeps them in <exe-dir>/data beside app.db and app.json.
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use tauri::{AppHandle, Emitter, Manager, WebviewUrl, WebviewWindow, WebviewWindowBuilder};

pub const CALENDAR_LABEL: &str = "calendar-float";
pub const TODO_LABEL: &str = "todo-float";
pub const SETTINGS_LABEL: &str = "widget-settings";
const CONFIG_FILE: &str = "desktop_widgets.json";
static CONFIG_LOCK: Mutex<()> = Mutex::new(());
static CALENDAR_GEOM_GEN: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static TODO_GEOM_GEN: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct WidgetLayout {
    /// Saved position in physical pixels; None means use the default placement.
    pub x: Option<i32>,
    pub y: Option<i32>,
    /// Saved size in logical pixels.
    pub width: f64,
    pub height: f64,
    pub locked: bool,
    pub visible: bool,
}
impl Default for WidgetLayout {
    fn default() -> Self {
        Self { x: None, y: None, width: 560.0, height: 320.0, locked: false, visible: true }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct WidgetAppearance {
    pub background_color: String,
    pub background_opacity: f64,
    pub text_color: String,
    pub weekday_color: String,
    pub weekend_color: String,
    pub today_color: String,
    pub font_family: String,
    pub font_size: f64,
    pub border_color: String,
}
impl Default for WidgetAppearance {
    fn default() -> Self {
        Self {
            background_color: "#20232b".into(), background_opacity: 0.86,
            text_color: "#f4f5f7".into(), weekday_color: "#dce1ea".into(),
            weekend_color: "#ff9b9b".into(), today_color: "#7ca8ff".into(),
            font_family: "Microsoft YaHei".into(), font_size: 13.0,
            border_color: "#5b6472".into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WidgetCategory {
    pub id: String,
    pub name: String,
    pub color: String,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalendarEvent {
    pub id: String,
    /// Local date key: YYYY-MM-DD
    pub date: String,
    pub title: String,
    pub category_id: String,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct DesktopWidgetConfig {
    pub appearance: WidgetAppearance,
    pub calendar: WidgetLayout,
    pub todo: WidgetLayout,
    pub categories: Vec<WidgetCategory>,
    pub urgencies: Vec<WidgetCategory>,
    pub events: Vec<CalendarEvent>,
}
impl Default for DesktopWidgetConfig {
    fn default() -> Self {
        Self {
            appearance: WidgetAppearance::default(),
            calendar: WidgetLayout { x: Some(40), y: Some(90), width: 570.0, height: 310.0, locked: false, visible: true },
            todo: WidgetLayout { x: Some(640), y: Some(90), width: 360.0, height: 480.0, locked: false, visible: true },
            categories: vec![
                WidgetCategory { id: "meeting".into(), name: "开会".into(), color: "#e25555".into() },
                WidgetCategory { id: "shift".into(), name: "排班".into(), color: "#43a879".into() },
                WidgetCategory { id: "personal".into(), name: "个人".into(), color: "#5388e8".into() },
            ],
            urgencies: vec![
                WidgetCategory { id: "normal".into(), name: "普通".into(), color: "#8b95a7".into() },
                WidgetCategory { id: "important".into(), name: "重要".into(), color: "#e7a23b".into() },
                WidgetCategory { id: "urgent".into(), name: "紧急".into(), color: "#e25555".into() },
            ],
            events: Vec::new(),
        }
    }
}

fn config_path() -> PathBuf { crate::paths::data_root().join(CONFIG_FILE) }
fn atomic_write(path: &Path, bytes: &[u8]) -> Result<(), String> {
    if let Some(parent) = path.parent() { std::fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, bytes).map_err(|e| e.to_string())?;
    #[cfg(windows)]
    if path.exists() { std::fs::remove_file(path).map_err(|e| e.to_string())?; }
    std::fs::rename(&tmp, path).map_err(|e| e.to_string())?;
    Ok(())
}
fn load_config_unlocked() -> DesktopWidgetConfig {
    let path = config_path();
    if let Ok(bytes) = std::fs::read(&path) {
        if let Ok(cfg) = serde_json::from_slice::<DesktopWidgetConfig>(&bytes) { return cfg; }
        log::warn!("桌面组件配置损坏，将备份并恢复默认: {}", path.display());
        let _ = std::fs::copy(&path, path.with_extension("json.bak"));
    }
    let cfg = DesktopWidgetConfig::default();
    if let Ok(bytes) = serde_json::to_vec_pretty(&cfg) { let _ = atomic_write(&path, &bytes); }
    cfg
}
fn save_config_unlocked(cfg: &DesktopWidgetConfig) -> Result<(), String> {
    let bytes = serde_json::to_vec_pretty(cfg).map_err(|e| e.to_string())?;
    atomic_write(&config_path(), &bytes)
}
pub fn get_config() -> Result<DesktopWidgetConfig, String> {
    let _guard = CONFIG_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    Ok(load_config_unlocked())
}
pub fn save_config(mut cfg: DesktopWidgetConfig) -> Result<(), String> {
    let _guard = CONFIG_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    // Settings and event edits must not overwrite geometry that changed after the settings
    // window loaded its snapshot.
    let old = load_config_unlocked();
    cfg.calendar = old.calendar;
    cfg.todo = old.todo;
    cfg.appearance.background_opacity = cfg.appearance.background_opacity.clamp(0.05, 1.0);
    cfg.appearance.font_size = cfg.appearance.font_size.clamp(9.0, 32.0);
    cfg.events.truncate(5000);
    save_config_unlocked(&cfg)
}

fn layout_mut(cfg: &mut DesktopWidgetConfig, label: &str) -> Result<&mut WidgetLayout, String> {
    match label { CALENDAR_LABEL => Ok(&mut cfg.calendar), TODO_LABEL => Ok(&mut cfg.todo), _ => Err("未知的桌面组件".into()) }
}
fn emit_changed(app: &AppHandle) { let _ = app.emit("desktop-widget-config-changed", ()); }

#[tauri::command]
pub fn get_desktop_widget_config() -> Result<DesktopWidgetConfig, String> { get_config() }
#[tauri::command]
pub fn save_desktop_widget_config(app: AppHandle, config: DesktopWidgetConfig) -> Result<(), String> {
    save_config(config)?; emit_changed(&app); Ok(())
}
#[tauri::command]
pub fn set_desktop_widget_locked(app: AppHandle, label: String, locked: bool) -> Result<(), String> {
    // Capture the current geometry before locking. This prevents a last drag/resize inside the
    // debounce interval from being lost when the lock flag makes the queued save a no-op.
    let geometry = app.get_webview_window(&label).and_then(read_geometry);
    {
        let _guard = CONFIG_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut cfg = load_config_unlocked();
        let layout = layout_mut(&mut cfg, &label)?;
        if let Some((x, y, width, height)) = geometry {
            layout.x = Some(x); layout.y = Some(y); layout.width = width; layout.height = height;
        }
        layout.locked = locked;
        save_config_unlocked(&cfg)?;
    }
    if let Some(win) = app.get_webview_window(&label) {
        win.set_resizable(!locked).map_err(|e| e.to_string())?;
        apply_bottom_layer(&win);
    }
    emit_changed(&app); Ok(())
}
#[tauri::command]
pub fn set_desktop_widget_visible(app: AppHandle, label: String, visible: bool) -> Result<(), String> {
    if !matches!(label.as_str(), CALENDAR_LABEL | TODO_LABEL) { return Err("未知的桌面组件".into()); }
    let geometry = if !visible { app.get_webview_window(&label).and_then(read_geometry) } else { None };
    {
        let _guard = CONFIG_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut cfg = load_config_unlocked();
        let layout = layout_mut(&mut cfg, &label)?;
        if !layout.locked {
            if let Some((x, y, width, height)) = geometry {
                layout.x = Some(x); layout.y = Some(y); layout.width = width; layout.height = height;
            }
        }
        layout.visible = visible;
        save_config_unlocked(&cfg)?;
    }
    if visible { show_widget(&app, &label)?; } else if let Some(win) = app.get_webview_window(&label) { let _ = win.hide(); }
    emit_changed(&app); Ok(())
}

#[tauri::command]
pub fn toggle_calendar_float(app: AppHandle) -> Result<(), String> { toggle_widget(&app, CALENDAR_LABEL) }
#[tauri::command]
pub fn toggle_widget_settings(app: AppHandle) -> Result<(), String> {
    if let Some(win) = app.get_webview_window(SETTINGS_LABEL) { let _ = win.show(); let _ = win.set_focus(); return Ok(()); }
    WebviewWindowBuilder::new(&app, SETTINGS_LABEL, WebviewUrl::App("index.html".into()))
        .title("桌面组件设置").inner_size(760.0, 640.0).min_inner_size(620.0, 500.0)
        .resizable(true).decorations(true).transparent(false).always_on_top(true).skip_taskbar(false)
        .visible(true).additional_browser_args(crate::ADDITIONAL_BROWSER_ARGS).build().map_err(|e| e.to_string())?;
    Ok(())
}

pub fn toggle_widget(app: &AppHandle, label: &str) -> Result<(), String> {
    let visible = app.get_webview_window(label).and_then(|w| w.is_visible().ok()).unwrap_or(false);
    if visible { set_desktop_widget_visible(app.clone(), label.to_string(), false) }
    else { set_desktop_widget_visible(app.clone(), label.to_string(), true) }
}
fn show_widget(app: &AppHandle, label: &str) -> Result<(), String> {
    let cfg = get_config()?;
    let layout = if label == CALENDAR_LABEL { cfg.calendar } else { cfg.todo };
    let win = if let Some(win) = app.get_webview_window(label) { win }
    else { build_widget(app, label, &layout)? };
    crate::win_taskbar::show(&win);
    let _ = win.unminimize();
    let _ = win.set_resizable(!layout.locked);
    apply_bottom_layer(&win);
    Ok(())
}
fn build_widget(app: &AppHandle, label: &str, layout: &WidgetLayout) -> Result<WebviewWindow, String> {
    let is_calendar = label == CALENDAR_LABEL;
    let (title, width, height) = if is_calendar { ("双周日程", layout.width, layout.height) } else { ("桌面待办", layout.width, layout.height) };
    let mut builder = WebviewWindowBuilder::new(app, label, WebviewUrl::App("index.html".into()))
        .title(title).inner_size(width, height).min_inner_size(if is_calendar { 420.0 } else { 280.0 }, if is_calendar { 200.0 } else { 220.0 })
        .resizable(true).decorations(false).transparent(true).always_on_top(false).skip_taskbar(true)
        .visible(false).additional_browser_args(crate::ADDITIONAL_BROWSER_ARGS);
    #[cfg(target_os = "windows")]
    { builder = builder.shadow(false).background_color(tauri::window::Color(0, 0, 0, 0)); }
    let win = builder.build().map_err(|e| e.to_string())?;
    if let (Some(x), Some(y)) = (layout.x, layout.y) {
        let _ = win.set_position(tauri::Position::Physical(tauri::PhysicalPosition::new(x, y)));
    } else if is_calendar { let _ = win.set_position(tauri::Position::Logical(tauri::LogicalPosition::new(40.0, 90.0))); }
    else { let _ = win.set_position(tauri::Position::Logical(tauri::LogicalPosition::new(640.0, 90.0))); }
    let _ = win.set_resizable(!layout.locked);
    attach_window_events(app, &win, label);
    crate::win_taskbar::apply(&win);
    Ok(win)
}

fn attach_window_events(app: &AppHandle, win: &WebviewWindow, label: &str) {
    let app = app.clone(); let label = label.to_string(); let watch = win.clone();
    win.on_window_event(move |event| match event {
        tauri::WindowEvent::Moved(_) | tauri::WindowEvent::Resized(_) => schedule_geometry_save(&app, &label, &watch),
        tauri::WindowEvent::Focused(true) => apply_bottom_layer(&watch),
        _ => {},
    });
}
fn read_geometry(win: WebviewWindow) -> Option<(i32, i32, f64, f64)> {
    let pos = win.outer_position().ok()?;
    let size = win.inner_size().ok()?;
    let scale = win.scale_factor().unwrap_or(1.0);
    let logical = size.to_logical::<f64>(scale);
    Some((pos.x, pos.y, logical.width, logical.height))
}

fn schedule_geometry_save(app: &AppHandle, label: &str, win: &WebviewWindow) {
    let generation = if label == CALENDAR_LABEL { &CALENDAR_GEOM_GEN } else { &TODO_GEOM_GEN };
    let gen = generation.fetch_add(1, std::sync::atomic::Ordering::AcqRel) + 1;
    let app = app.clone(); let label = label.to_string(); let win = win.clone();
    tauri::async_runtime::spawn(async move {
        tokio::time::sleep(std::time::Duration::from_millis(500)).await;
        let g = if label == CALENDAR_LABEL { &CALENDAR_GEOM_GEN } else { &TODO_GEOM_GEN };
        if g.load(std::sync::atomic::Ordering::Acquire) != gen { return; }
        let Ok(pos) = win.outer_position() else { return };
        let Ok(size) = win.inner_size() else { return };
        let scale = win.scale_factor().unwrap_or(1.0);
        let logical = size.to_logical::<f64>(scale);
        let _guard = CONFIG_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let mut cfg = load_config_unlocked();
        if let Ok(layout) = layout_mut(&mut cfg, &label) {
            if layout.locked { return; }
            layout.x = Some(pos.x); layout.y = Some(pos.y); layout.width = logical.width; layout.height = logical.height;
            if let Err(e) = save_config_unlocked(&cfg) { log::warn!("桌面组件几何保存失败: {e}"); }
        }
        emit_changed(&app);
    });
}

pub fn init_widgets(app: &AppHandle) {
    let Ok(cfg) = get_config() else { return };
    if cfg.calendar.visible { if let Err(e) = show_widget(app, CALENDAR_LABEL) { log::warn!("创建双周日程组件失败: {e}"); } }
    if cfg.todo.visible { if let Err(e) = show_widget(app, TODO_LABEL) { log::warn!("创建桌面待办组件失败: {e}"); } }
}

#[cfg(target_os = "windows")]
fn apply_bottom_layer(win: &WebviewWindow) {
    use windows_sys::Win32::UI::WindowsAndMessaging::{SetWindowPos, HWND_BOTTOM, SWP_NOACTIVATE, SWP_NOMOVE, SWP_NOSIZE, SWP_NOOWNERZORDER};
    if let Ok(hwnd) = win.hwnd() { unsafe { SetWindowPos(hwnd.0, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER); } }
}
#[cfg(not(target_os = "windows"))]
fn apply_bottom_layer(_win: &WebviewWindow) {}
