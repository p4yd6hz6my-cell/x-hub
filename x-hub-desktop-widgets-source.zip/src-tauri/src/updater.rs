//! 应用自动升级（方案 A：自研 update.json + 摘要签名 + rename 自替换）。
//!
//! 升级清单 `releases/update.json` 紧随市场清单之后扩展：发布侧用同一把
//! Ed25519 私钥对原始字节做分离签名（`.sig` 文本文件并列上传），客户端以
//! 内嵌公钥验签（`signing::verify_detached`），通过才信任清单内容——
//! 清单是唯一安全根，下载物（新版本 zip）的 sha256 均由签名清单背书。
//!
//! 流程（对应文档 §6.2）：
//!   ① `check_for_update`：拉取 update.json + .sig → 验签 → semver 比较 +
//!      `minimumUpgradable` 跳级保护 → 平台匹配（便携版优先 portableUrl）→
//!      广播 `update-available`（版本/说明/大小）。
//!   ② `download_update`：按清单下载新版本 zip → 边下边算 sha256（与清单
//!      比对）→ 落 `data_root()/updates/<version>/x-hub.zip` →
//!      写 `data_root()/updates/.pending.json` 标记，广播 `update-ready`。
//!   ③ `apply_pending_update`：每次启动早期调用（幂等）。无标记直接跳过；
//!      待应用版本不高于当前版本（如已手动装了更高版）→ 清理过期包防降级；
//!      有标记 → 解包 → `exe → exe.old` / `新 exe → exe` 两步就位
//!      （Windows 允许 rename 正在运行的 exe；数据根与 exe 跨盘时 rename
//!      报 os error 17，move_file 退化为复制）→ 校验新 exe 具名 → 删 .old。
//!      就位成功后立即以新 exe 拉起子进程接管启动、当前进程退出——当前
//!      进程镜像已被改名成 .old，原地继续跑只会是旧版本。任一步失败
//!      回滚并保留标记，下次启动重试。启动时顺手清理上次升级残留的 .old。
//!      拉起后、退出前必须先 `tauri_plugin_single_instance::destroy` 释放单
//!      实例互斥与隐藏窗口：否则新实例启动时插件 setup 里 CreateMutexW 会撞
//!      上旧进程未释放的互斥（旧进程 std::process::exit 不触发插件的 Exit
//!      清理），新实例被判为「第二实例」自杀退出——表现为升级后应用没有自动
//!      重启，需用户手动再开（历史反复出现的现象，顺序见 `relaunch_app` 注释：
//!      先 spawn 成功再 destroy，失败路径不触碰互斥以防双实例）。
//!
//! 事件：`update-available`、`update-download-progress`、`update-ready`。

use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::time::Duration;
use tauri::Emitter;
use tauri::Manager;

/// 更新清单 schema 版本。
const SCHEMA_VERSION: u32 = 1;

/// 待应用更新标记文件：`data_root()/updates/.pending.json`
const PENDING_FILE: &str = ".pending.json";

/// 下载互斥标志：同一时刻只允许一个 download_update 在跑。
/// 并发触发会各自 File::create 截断同一临时文件互踩，必须拒绝而非排队
static DOWNLOAD_IN_FLIGHT: AtomicBool = AtomicBool::new(false);

/// 「稍后再提示」补检去重：每点一次递增代数，只有代数仍最新的那个补检任务
/// 到期才真正执行检查。连点「稍后再提示」时暂停窗口本来就顺延到最后一次点击
/// （`update_snooze_until_ms` 覆盖写），这里再让旧的补检任务到点后自行退出，
/// 避免排出一串同一时刻的重复检查。
static SNOOZE_GENERATION: AtomicU64 = AtomicU64::new(0);

/// download_update 的守卫：任何退出路径（含 ? / panic 展开）都复位互斥标志
struct DownloadGuard;
impl Drop for DownloadGuard {
    fn drop(&mut self) {
        DOWNLOAD_IN_FLIGHT.store(false, Ordering::Release);
    }
}

/// 下载根目录：`data_root()/updates/<version>/`
fn updates_root() -> Result<PathBuf, String> {
    Ok(crate::paths::data_root().join("updates"))
}

fn pending_file() -> Result<PathBuf, String> {
    Ok(updates_root()?.join(PENDING_FILE))
}

/// 更新清单（远端 `update.json`），字段与文档 §6.1 一致。
#[derive(Debug, Clone, Deserialize)]
struct UpdateManifest {
    #[serde(rename = "schemaVersion")]
    schema_version: u32,
    /// 新版本号（对比当前版本决定是否可更新）
    #[serde(default)]
    version: String,
    /// 可升级的最低版本下限（跳级保护）
    #[serde(default, rename = "minimumUpgradable")]
    minimum_upgradable: String,
    /// 更新说明摘要（下载前给用户看）
    #[serde(default)]
    notes: String,
    /// 平台条目：`windows-x86_64` → 下载信息
    #[serde(default)]
    platforms: std::collections::HashMap<String, PlatformEntry>,
}

impl Default for UpdateManifest {
    fn default() -> Self {
        Self {
            schema_version: SCHEMA_VERSION,
            version: String::new(),
            minimum_upgradable: String::new(),
            notes: String::new(),
            platforms: std::collections::HashMap::new(),
        }
    }
}

/// 单个平台的下载信息。
#[derive(Debug, Clone, Deserialize)]
struct PlatformEntry {
    /// 标准版下载地址（zip）
    #[serde(default)]
    url: String,
    /// 便携版下载地址（zip，便携版优先）
    #[serde(default, rename = "portableUrl")]
    portable_url: String,
    /// 标准版 zip 的 sha256（hex 小写）
    #[serde(default)]
    sha256: String,
    /// 便携版 zip 的 sha256（hex 小写）
    #[serde(default, rename = "portableSha256")]
    portable_sha256: String,
    /// zip 字节大小（0 = 未知，仅作进度参考）
    #[serde(default)]
    size: u64,
    /// 便携版 zip 字节大小（0 = 未知）
    #[serde(default, rename = "portableSize")]
    portable_size: u64,
}

impl Default for PlatformEntry {
    fn default() -> Self {
        Self {
            url: String::new(),
            portable_url: String::new(),
            sha256: String::new(),
            portable_sha256: String::new(),
            size: 0,
            portable_size: 0,
        }
    }
}

/// 前端查询/收到的更新信息（`get_update_status` / `update-available` 负载）。
#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UpdateInfo {
    /// 是否有可用更新（已命中版本且未下载）
    pub available: bool,
    /// 目标版本号（空 = 无目标版本）
    pub version: String,
    /// 更新说明摘要
    pub notes: String,
    /// 本次更新 zip 大小（0 = 未知）
    pub size: u64,
    /// 该更新是否为便携版专属（决定下载哪个 URL / 校验哪个 sha256）
    pub portable: bool,
    /// 是否已就绪待重启应用（下载完成并写好标记）
    pub ready: bool,
    /// 当前应用的版本号
    pub current: String,
}

impl UpdateInfo {
    fn none(current: &str) -> Self {
        Self {
            available: false,
            version: String::new(),
            notes: String::new(),
            size: 0,
            portable: false,
            ready: false,
            current: current.to_string(),
        }
    }
}

fn current_version(app: &tauri::AppHandle) -> String {
    app.package_info().version.to_string()
}

/// 解析更新清单。
fn parse_manifest(bytes: &[u8]) -> Result<UpdateManifest, String> {
    let m: UpdateManifest = serde_json::from_slice(bytes).map_err(|e| format!("清单解析失败: {e}"))?;
    if m.schema_version > SCHEMA_VERSION {
        return Err(format!(
            "升级清单 schemaVersion={} 高于宿主支持的 v{SCHEMA_VERSION}",
            m.schema_version
        ));
    }
    if m.version.is_empty() {
        return Err("升级清单缺少 version 字段".to_string());
    }
    Ok(m)
}

/// 一次性拉取 URL 内容（字节），非 2xx 视为失败。
async fn fetch_bytes(client: &reqwest::Client, url: &str) -> Result<Vec<u8>, String> {
    let resp = client
        .get(url)
        .send()
        .await
        .map_err(|e| format!("通信失败：{e}"))?;
    if !resp.status().is_success() {
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        // 升级清单走平台服务端（v0.6.1 起）：4xx/5xx 是 JSON `{error, message}`，
        // 优先带出服务端的可读 message；包下载（COS 直连）非 JSON 时退回状态码
        let msg = serde_json::from_str::<serde_json::Value>(&body)
            .ok()
            .and_then(|v| v.get("message").and_then(|m| m.as_str()).map(|s| s.to_string()))
            .unwrap_or_else(|| format!("HTTP {status}"));
        return Err(msg);
    }
    let bytes = resp.bytes().await.map_err(|e| format!("读取响应失败: {e}"))?;
    Ok(bytes.to_vec())
}

/// 脱敏更新源错误信息：不向用户暴露具体 URL。
fn sanitize_update_error(mut msg: String, endpoint: &str, sig_url: &str) -> String {
    for url in [endpoint, sig_url] {
        msg = msg.replace(url, "(更新源地址)");
    }
    msg
}

/// 更新清单地址（内置常量：平台服务端接口，服务端再代理 COS）。
fn update_endpoint() -> String {
    crate::config::update_manifest_url()
}

/// 拉取更新清单并验签（未验签通过一律不信任）。返回 `(清单, 原字节)`。
async fn fetch_manifest(client: &reqwest::Client) -> Result<(UpdateManifest, Vec<u8>), String> {
    let endpoint = update_endpoint();
    let sig_url = format!("{endpoint}.sig");
    let content = fetch_bytes(client, &endpoint)
        .await
        .map_err(|e| sanitize_update_error(format!("拉取更新清单失败：{e}"), &endpoint, &sig_url))?;
    let sig = fetch_bytes(client, &sig_url)
        .await
        .map_err(|e| sanitize_update_error(format!("拉取清单签名失败：{e}"), &endpoint, &sig_url))?;
    let sig = String::from_utf8_lossy(&sig).into_owned();
    crate::signing::verify_detached(&content, &sig)
        .map_err(|e| format!("更新清单验签失败：{e}"))?;
    let manifest = parse_manifest(&content)?;
    Ok((manifest, content))
}

fn to_hex(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

fn version_cmp(a: &str, b: &str) -> std::cmp::Ordering {
    crate::market::version_cmp(a, b)
}

/// 解析平台条目：取 `windows-x86_64`；便携版优先 portableUrl。
fn platform_entry(manifest: &UpdateManifest) -> Option<(PlatformEntry, bool)> {
    let entry = manifest.platforms.get("windows-x86_64")?;
    let portable = crate::paths::is_portable();
    let available = if portable {
        !entry.portable_url.is_empty()
    } else {
        !entry.url.is_empty()
    };
    if !available {
        return None;
    }
    Some((entry.clone(), portable))
}

/// 判断候选版本是否可比当前版本更新（semver；含 minimumUpgradable 跳级保护）。
fn is_newer(manifest: &UpdateManifest, current: &str) -> bool {
    if manifest.version.is_empty() {
        return false;
    }
    if version_cmp(&manifest.version, current) != std::cmp::Ordering::Greater {
        return false;
    }
    if !manifest.minimum_upgradable.is_empty()
        && version_cmp(current, &manifest.minimum_upgradable) == std::cmp::Ordering::Less
    {
        log::info!(
            "更新源版本 v{} 要求最低可升级 v{}，当前 v{}，跳级保护拦截",
            manifest.version,
            manifest.minimum_upgradable,
            current
        );
        return false;
    }
    true
}

/// 检查是否有可用更新。验签失败 / 通信失败时**静默**返回"无更新"
/// （记日志不打扰用户），只有真正命中才广播 `update-available`。
///
/// `manual`：是否由用户手动触发（About 页「检查更新」）。手动检查时
/// **忽略**「跳过此版本」记录——用户主动查看，应能再次看到该版本。
#[tauri::command]
pub async fn check_for_update(
    app: tauri::AppHandle,
    manual: Option<bool>,
) -> Result<UpdateInfo, String> {
    let manual = manual.unwrap_or(false);
    let current = current_version(&app);
    // 更新清单来自平台服务端（国内）：强制直连，别被用户本地代理带沟里（见 crate::net）
    let client = crate::net::direct()
        .timeout(Duration::from_secs(20))
        .build()
        .map_err(|e| format!("HTTP 客户端初始化失败: {e}"))?;

    let (manifest, _) = match fetch_manifest(&client).await {
        Ok(m) => m,
        Err(e) => {
            log::warn!("更新检查失败（静默）: {e}");
            // 手动检查（About 页）应向上报错，让前端提示失败原因；
            // 仅自动检查静默降级为"无更新"
            if manual {
                return Err(e);
            }
            return Ok(UpdateInfo::none(&current));
        }
    };

    if !is_newer(&manifest, &current) {
        log::info!("已是最新版本（当前 v{current}，源 v{}）", manifest.version);
        return Ok(UpdateInfo::none(&current));
    }
    // 用户「跳过此版本」：与清单目标版本一致时不再提示（记录到 config）。
    // 仅自动检查时生效——手动检查更新应能再次看到并选择升级。
    if !manual && crate::config::load().skipped_update_version == manifest.version {
        log::info!("版本 v{} 已被用户跳过，不再提示", manifest.version);
        return Ok(UpdateInfo::none(&current));
    }
    // 「稍后再提示」：暂停窗口内自动检查不弹（见 snooze_update；手动检查不受影响）。
    // 到期后由 snooze_update 安排的补检或 4h 周期循环再次提示。
    if !manual {
        let snooze_until = crate::config::load().update_snooze_until_ms;
        if snooze_until > 0 && now_epoch_ms() < snooze_until {
            log::info!("更新提示处于「稍后再提示」暂停窗口内，本轮不弹");
            return Ok(UpdateInfo::none(&current));
        }
    }
    let (entry, portable) = match platform_entry(&manifest) {
        Some(p) => p,
        None => {
            log::warn!("更新源无当前平台条目（windows-x86_64）");
            return Ok(UpdateInfo::none(&current));
        }
    };

    let info = UpdateInfo {
        available: true,
        version: manifest.version.clone(),
        notes: manifest.notes.clone(),
        size: if portable { entry.portable_size } else { entry.size },
        portable,
        ready: false,
        current,
    };
    log::info!(
        "发现新版本 v{}（{}，{:.1} MB，便携版={}）",
        manifest.version,
        if portable { "portable" } else { "standard" },
        (if portable { entry.portable_size } else { entry.size }) as f64 / 1048576.0,
        portable
    );
    let _ = app.emit("update-available", &info);
    Ok(info)
}

fn now_epoch_ms() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

/// 「稍后再提示」：把更新弹窗暂停 30 分钟（写 `update_snooze_until_ms`），到点后
/// 主动补一次自动检查。为什么补检：静默检查循环是 4h 一跳，不补检的话「稍后」
/// 实际会变成「最多 4 小时后」。手动检查（About 页）不受暂停窗口影响。
#[tauri::command]
pub fn snooze_update(app: tauri::AppHandle) -> Result<(), String> {
    const SNOOZE_MINUTES: i64 = 30;
    {
        let _guard = crate::config::lock();
        let mut cfg = crate::config::load();
        cfg.update_snooze_until_ms = now_epoch_ms() + SNOOZE_MINUTES * 60_000;
        crate::config::save(&cfg)?;
    }
    // 取一个本次点击专属的代数；期间又点了「稍后再提示」的话代数会变大，
    // 本任务到点后据此直接退出，只留最新一次去补检
    let generation = SNOOZE_GENERATION.fetch_add(1, Ordering::AcqRel) + 1;
    let handle = app.clone();
    tauri::async_runtime::spawn(async move {
        tokio::time::sleep(Duration::from_secs((SNOOZE_MINUTES * 60) as u64)).await;
        if SNOOZE_GENERATION.load(Ordering::Acquire) != generation {
            log::info!("「稍后再提示」期间有更新的点击，本次补检跳过（已由最新那次顺延）");
            return;
        }
        // 补检同受「自动检查更新」总开关控制（与 lib.rs 静默循环同口径）：用户在暂停
        // 窗口内关掉开关就是不想再被打扰，到期补检不能成为绕过开关的旁路
        if !crate::config::load().auto_update_enabled {
            log::info!("「稍后再提示」到期补检被跳过：自动检查更新已关闭");
            return;
        }
        if let Ok(info) = check_for_update(handle, None).await {
            log::info!(
                "「稍后再提示」到期补检：{}",
                if info.available { "仍有更新" } else { "无更新" }
            );
        }
    });
    log::info!("更新提示已推迟 {} 分钟", SNOOZE_MINUTES);
    Ok(())
}

/// 下载可用更新（`check_for_update` 命中后调用）。
/// 重新拉取清单并验签（保证下载依据仍是最新签名清单）→ 取对应平台条目 →
/// 流式下载 → 边下边算 sha256 校验 → 写 `updates/<version>/x-hub.zip` →
/// 写 `.pending.json` → 广播 `update-ready`。
///
/// 前端传入 `version` 仅为目标版本校验：下载时若清单中的目标版本与请求不符
/// 则中止（防并发/竞态下下载旧条目）。
///
/// ⚠️ 本命令是**用户确认后的手动路径**，全工程唯一调用点是 UpdateCheckDialog 的
/// 「立即更新」按钮——因此**执行点不查 `auto_update_enabled`**（那个开关只约束
/// 「自动检查」，与 About 页手动「检查更新」按钮同语义空间，关掉开关后手动下载
/// 必须仍然可用）。**不要从任何自动流程直接调用本命令**：将来若新增自动下载，
/// 必须像 check_for_update 的 `manual` 参数一样先过开关闸（反馈 2026-10-01）。
#[tauri::command]
pub async fn download_update(
    app: tauri::AppHandle,
    version: String,
) -> Result<UpdateInfo, String> {
    // 互斥进入：慢链路下载会持续数分钟，期间重复触发只会截断重下
    if DOWNLOAD_IN_FLIGHT
        .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
        .is_err()
    {
        return Err("已有下载任务进行中，请等待其完成（或重启应用中断）".to_string());
    }
    let _download_guard = DownloadGuard;
    let current = current_version(&app);
    // 不设总超时：慢链路（~30KB/s）下载 8.7MB 需数分钟，总超时必然误杀慢而活跃的下载；
    // 改为连接超时 + 空闲读超时（30s 收不到新数据才断），下面的流式读取同样吃 read_timeout
    // 安装包由我们自己的分发（COS 国内）提供：同样强制直连（见 crate::net）
    let client = crate::net::direct()
        .connect_timeout(Duration::from_secs(15))
        .read_timeout(Duration::from_secs(30))
        .build()
        .map_err(|e| format!("HTTP 客户端初始化失败: {e}"))?;

    // 断点续传 + 自动重试：慢链路上长连接易被中途掐断（reqwest 统一报
    // "error decoding response body"），每次尝试都从 tmp 已有字节数 Range 续传（R2 支持 206），
    // 失败退避后自动再试直到成功或重试额度用完；残片不小于预期总大小时视为脏文件丢弃
    const MAX_ATTEMPTS: u32 = 8;
    const RETRY_DELAY: Duration = Duration::from_secs(2);

    // 清单 + 签名两次 GET：接入层瞬时异常（一次 404/超时）不该让整单失败，轻量重试兜底
    const MANIFEST_ATTEMPTS: u32 = 3;
    let (manifest, _) = {
        let mut last_err = String::new();
        let mut got = None;
        for attempt in 1..=MANIFEST_ATTEMPTS {
            match fetch_manifest(&client).await {
                Ok(v) => {
                    got = Some(v);
                    break;
                }
                Err(e) => {
                    last_err = e;
                    log::warn!("更新清单拉取第 {attempt}/{MANIFEST_ATTEMPTS} 次失败: {last_err}");
                    if attempt < MANIFEST_ATTEMPTS {
                        tokio::time::sleep(RETRY_DELAY).await;
                    }
                }
            }
        }
        match got {
            Some(v) => v,
            None => return Err(last_err),
        }
    };
    if !manifest.version.eq(&version) {
        return Err(format!(
            "更新源已变更（目标 v{version}，清单 v{}），请重新检查更新",
            manifest.version
        ));
    }
    let (entry, portable) = platform_entry(&manifest).ok_or_else(|| {
        format!("更新源无当前平台条目（windows-x86_64，版本 v{version}）")
    })?;
    let (url, sha256) = if portable {
        (entry.portable_url.clone(), entry.portable_sha256.clone())
    } else {
        (entry.url.clone(), entry.sha256.clone())
    };
    if url.is_empty() {
        return Err("更新清单缺少下载地址".to_string());
    }

    // 目录准备：updates/<version>/
    let ver_dir = updates_root()?.join(&version);
    std::fs::create_dir_all(&ver_dir).map_err(|e| format!("创建更新目录失败: {e}"))?;
    let zip_path = ver_dir.join("x-hub.zip");
    let tmp_zip = ver_dir.join("x-hub.zip.tmp");

    // 失败退避后自动再试直到成功或重试额度用完；残片不小于预期总大小时视为脏文件丢弃
    let manifest_size = if portable { entry.portable_size } else { entry.size };
    let mut attempt: u32 = 0;
    let downloaded;
    loop {
        attempt += 1;
        // 每次尝试重新读残片长度（上次尝试可能又推进了一些）
        let mut offset: u64 = 0;
        if tmp_zip.is_file() {
            let existing = std::fs::metadata(&tmp_zip).map(|m| m.len()).unwrap_or(0);
            if existing > 0 && (manifest_size == 0 || existing < manifest_size) {
                offset = existing;
            } else if existing > 0 {
                let _ = std::fs::remove_file(&tmp_zip);
            }
        }

        let mut request = client.get(&url);
        if offset > 0 {
            request = request.header("Range", format!("bytes={offset}-"));
        }
        let resp = match request.send().await {
            Ok(r) => r,
            Err(e) => {
                if attempt < MAX_ATTEMPTS {
                    log::warn!(
                        "更新下载第 {attempt} 次尝试失败（{e}），{}s 后从 {} 字节处续传",
                        RETRY_DELAY.as_secs(),
                        offset
                    );
                    tokio::time::sleep(RETRY_DELAY).await;
                    continue;
                }
                return Err(format!("下载失败: {e}"));
            }
        };
        // 残片与服务端文件不一致（如清单与服务端包不同步）→ Range 越界 416：丢弃残片重下
        if resp.status() == reqwest::StatusCode::RANGE_NOT_SATISFIABLE {
            let _ = std::fs::remove_file(&tmp_zip);
            if attempt < MAX_ATTEMPTS {
                log::warn!("更新续传偏移越界（416），已丢弃残片重新下载");
                continue;
            }
            return Err("更新残片与服务端文件不一致，已重置下载，请重试".to_string());
        }
        if !resp.status().is_success() {
            // 非 2xx（含 404/403 瞬态）同样退避重试：接入层抖动一次不该让用户手点失败
            if attempt < MAX_ATTEMPTS {
                log::warn!(
                    "更新下载第 {attempt} 次尝试返回 HTTP {}，{}s 后重试（从 {offset} 字节处续传）",
                    resp.status(),
                    RETRY_DELAY.as_secs()
                );
                tokio::time::sleep(RETRY_DELAY).await;
                continue;
            }
            return Err(format!("下载失败: HTTP {}", resp.status()));
        }
        // 服务器不支持 Range（回 200 全量而非 206）时清零从头下
        let resumed = offset > 0 && resp.status() == reqwest::StatusCode::PARTIAL_CONTENT;
        if offset > 0 && !resumed {
            offset = 0;
        }
        let total = if manifest_size > 0 {
            Some(manifest_size)
        } else {
            resp.content_length().map(|l| l + offset)
        };
        let mut file = if resumed {
            std::fs::OpenOptions::new()
                .append(true)
                .open(&tmp_zip)
                .map_err(|e| format!("打开续传文件失败: {e}"))?
        } else {
            std::fs::File::create(&tmp_zip).map_err(|e| format!("创建文件失败: {e}"))?
        };
        let mut stream = resp.bytes_stream();
        let mut done: u64 = offset;
        let mut last_emit: u64 = offset;
        let mut interrupted: Option<String> = None;
        while let Some(chunk) = stream.next().await {
            match chunk {
                Ok(bytes) => {
                    file.write_all(&bytes).map_err(|e| format!("写入失败: {e}"))?;
                    done += bytes.len() as u64;
                    if done - last_emit >= 262_144 || total == Some(done) {
                        last_emit = done;
                        let _ = app.emit(
                            "update-download-progress",
                            crate::market::DownloadProgress {
                                id: "x-hub".to_string(),
                                received: done,
                                total,
                            },
                        );
                    }
                }
                Err(e) => {
                    // 连接被掐断：保留已写入部分，退避后续传
                    interrupted = Some(format!("下载中断: {e}"));
                    break;
                }
            }
        }
        file.flush().map_err(|e| format!("落盘失败: {e}"))?;
        drop(file);
        match interrupted {
            Some(msg) => {
                if attempt < MAX_ATTEMPTS {
                    log::warn!(
                        "更新下载第 {attempt} 次尝试中断于 {} 字节，{}s 后续传",
                        done,
                        RETRY_DELAY.as_secs()
                    );
                    tokio::time::sleep(RETRY_DELAY).await;
                    continue;
                }
                return Err(msg);
            }
            None => {
                if last_emit != done {
                    let _ = app.emit("update-download-progress", crate::market::DownloadProgress {
                        id: "x-hub".to_string(),
                        received: done,
                        total,
                    });
                }
                downloaded = done;
                break;
            }
        }
    }
    if manifest_size != 0 && downloaded != manifest_size {
        // 流正常结束但长度与清单不符：服务端包与清单可能不同步，续传救不了系统性偏差
        return Err(format!(
            "下载不完整: 收到 {downloaded} 字节，预期 {manifest_size} 字节（更新源与清单可能不同步）"
        ));
    }
    // 校验完整性（清单背书）。续传时前段字节未经 hasher，全量从盘上文件重算（8MB 级瞬间完成）
    if !sha256.is_empty() {
        let whole = std::fs::read(&tmp_zip).map_err(|e| format!("读取下载文件失败: {e}"))?;
        let mut hasher = Sha256::new();
        hasher.update(&whole);
        let actual = to_hex(&hasher.finalize());
        drop(whole);
        if !actual.eq_ignore_ascii_case(&sha256) {
            let _ = std::fs::remove_file(&tmp_zip);
            return Err(format!(
                "下载校验失败（sha256 不匹配）\n期望: {sha256}\n实际: {actual}\n更新包可能被篡改或损坏，已中止。"
            ));
        }
    }
    // 就位（rename 原子）
    std::fs::rename(&tmp_zip, &zip_path).map_err(|e| format!("更新包就位失败: {e}"))?;

    // 写待应用标记
    let pending = serde_json::json!({
        "version": manifest.version.clone(),
        "zipPath": zip_path.to_string_lossy().to_string(),
        "portable": portable,
    });
    std::fs::write(pending_file()?, serde_json::to_vec_pretty(&pending).unwrap_or_default())
        .map_err(|e| format!("写入更新标记失败: {e}"))?;

    log::info!(
        "更新已下载就绪: v{} -> v{}（{} 字节，便携版={}）",
        current,
        manifest.version,
        downloaded,
        portable
    );
    let info = UpdateInfo {
        available: true,
        version: manifest.version.clone(),
        notes: manifest.notes.clone(),
        size: if portable { entry.portable_size } else { entry.size },
        portable,
        ready: true,
        current,
    };
    let _ = app.emit("update-ready", &info);
    Ok(info)
}

/// 当前更新状态（不发起网络请求）：读取本地标记与配置，供前端展示。
#[tauri::command]
pub fn get_update_status(app: tauri::AppHandle) -> Result<UpdateInfo, String> {
    let current = current_version(&app);
    let mut info = UpdateInfo::none(&current);
    if let Some(pending) = read_pending() {
        info.available = true;
        info.version = pending.version;
        info.portable = pending.portable;
        info.ready = true;
    }
    Ok(info)
}

/// 记录用户「跳过此版本」：将该版本号持久化到 config，后续检查更新时不再提示该版本。
#[tauri::command]
pub fn skip_update_version(version: String) -> Result<(), String> {
    let version = version.trim().to_string();
    if version.is_empty() {
        return Err("版本号不能为空".to_string());
    }
    let _guard = crate::config::lock();
    let mut config = crate::config::load();
    config.skipped_update_version = version.clone();
    crate::config::save(&config)?;
    log::info!("已跳过版本 v{}，后续检查不再提示", version);
    Ok(())
}

/// 待应用更新标记。
#[derive(Debug, Clone, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct PendingUpdate {
    version: String,
    #[serde(default)]
    zip_path: String,
    #[serde(default)]
    portable: bool,
}

fn read_pending() -> Option<PendingUpdate> {
    let path = pending_file().ok()?;
    if !path.is_file() {
        return None;
    }
    let content = std::fs::read_to_string(&path).ok()?;
    serde_json::from_str::<PendingUpdate>(&content).ok()
}

/// 应用待更新版本（每次启动早期调用，幂等）。
/// Windows 允许 rename 正在运行的 exe：`exe → exe.old`、`新 exe → exe`。
/// 任一步失败回滚（.old 还原）并保留标记，下次启动重试。
/// 成功则删除标记 + 更新包，并立即以新 exe 拉起子进程、当前进程退出——
/// 当前进程镜像已被改名成 .old，原地继续跑的仍是旧版本（「点了重启
/// 还是旧版」的根因）。新实例再进这里时无标记，直接跳过，不会循环。
/// 另外每次进入先清理上次升级残留的 .old（此刻已无进程占用，可安全删）。
/// 拉起走 `relaunch_app`（先释放 single-instance 互斥，见其注释）。
pub fn apply_pending_update(app: &tauri::AppHandle, current_version: &str) {
    // 清理上次自替换残留的 .old：升级时运行中进程的镜像被改名成了
    // exe.old，Windows 不允许删除运行中进程的镜像文件，当时必删失败；
    // 等到下一次启动它已无进程占用，这里统一清掉，避免 exe 目录长期躺着 .old
    if let Ok(exe_path) = std::env::current_exe() {
        if let Some(exe_dir) = exe_path.parent() {
            let _ = std::fs::remove_file(exe_dir.join(exe_file_name_with_old(&exe_path)));
        }
    }
    let Some(pending) = read_pending() else {
        return;
    };
    // 待应用版本不高于当前版本（用户可能已手动装了更高版本）：清掉过期
    // 更新包与标记，防止启动时旧包把新装的 exe 又覆盖回旧版（降级）
    if version_cmp(&pending.version, current_version) != std::cmp::Ordering::Greater {
        log::info!(
            "待应用更新 v{} 不高于当前版本 v{}，清理过期更新包",
            pending.version,
            current_version
        );
        discard_pending(&pending);
        return;
    }
    let zip_path = PathBuf::from(&pending.zip_path);
    if !zip_path.is_file() {
        log::warn!("待应用更新包不存在（{}），清理标记", zip_path.display());
        discard_pending(&pending);
        return;
    }

    let exe_path = match std::env::current_exe() {
        Ok(p) => p,
        Err(e) => {
            log::warn!("无法定位当前 exe（{e}），跳过本次应用更新");
            return;
        }
    };
    let exe_dir = match exe_path.parent() {
        Some(d) => d.to_path_buf(),
        None => {
            log::warn!("无法定位 exe 目录，跳过本次应用更新");
            return;
        }
    };

    // 解包新版本到同一目录下的隐藏暂存目录
    let version_dir = match updates_root() {
        Ok(d) => d.join(&pending.version),
        Err(_) => return,
    };
    let staging = version_dir.join(".staging");
    if staging.exists() {
        let _ = std::fs::remove_dir_all(&staging);
    }
    let staging_tmp = version_dir.join(".staging.tmp");
    if staging_tmp.exists() {
        let _ = std::fs::remove_dir_all(&staging_tmp);
    }
    if let Err(e) = crate::market::extract_zip_read(&zip_path, &staging_tmp) {
        log::warn!("更新包解包失败（{}），跳过本次应用更新，稍后重试", e);
        let _ = std::fs::remove_dir_all(&staging_tmp);
        return;
    }

    // 解包结果里找到真正可执行的 exe（根或一层子目录；Windows 平台产物名不定，
    // 统一取 `.exe` 后缀且体积最大的候选；无则失败回滚）
    let new_exe = locate_new_exe(&staging_tmp);
    let Some(new_exe) = new_exe else {
        log::warn!("更新包内未找到可执行文件（.exe），跳过应用更新");
        let _ = std::fs::remove_dir_all(&staging_tmp);
        return;
    };
    // 校验新 exe 不是当前正在运行的自己（防更新包误打包旧版）
    if new_exe == exe_path {
        log::warn!("更新包内 exe 与当前一致，疑似打包异常，跳过");
        let _ = std::fs::remove_dir_all(&staging_tmp);
        return;
    }

    if let Err(e) = std::fs::rename(&staging_tmp, &staging) {
        log::warn!("更新暂存目录就位失败（{e}），跳过本次应用更新");
        let _ = std::fs::remove_dir_all(&staging_tmp);
        return;
    }
    // 新 exe 相对暂存根目录的偏移（可能在子目录），rename 后同样相对 staging 拼接
    let rel = new_exe
        .strip_prefix(&staging_tmp)
        .unwrap_or_else(|_| std::path::Path::new(new_exe.file_name().unwrap_or_default()));
    let new_in_staging = staging.join(rel);

    // 自替换：两步 rename
    // 1) exe → exe.old（可能已存在 .old 残留：先清掉旧残留）
    let old_path = exe_dir.join(exe_file_name_with_old(&exe_path));
    let _ = std::fs::remove_file(&old_path);
    if let Err(e) = std::fs::rename(&exe_path, &old_path) {
        log::warn!("备份当前 exe 失败（{e}），跳过本次应用更新");
        let _ = std::fs::remove_dir_all(&staging);
        return;
    }
    // 2) 新 exe → exe；数据根与 exe 不同盘时 rename 报 os error 17，
    //    move_file 内部退化为复制；失败则回滚
    if let Err(e) = move_file(&new_in_staging, &exe_path) {
        log::error!("安装新版本失败（{e}），回滚到旧版本");
        let _ = std::fs::rename(&old_path, &exe_path);
        let _ = std::fs::remove_dir_all(&staging);
        return;
    }
    // 3) 清理新包残余（.old 是当前运行中进程的镜像，Windows 不允许删除，
    //    必删失败属预期；留给下一次启动的开头统一清理）
    let _ = std::fs::remove_file(&old_path);
    let _ = std::fs::remove_dir_all(&staging);
    let _ = std::fs::remove_file(&zip_path);
    let _ = remove_pending_file();

    log::info!("应用已自替换升级到 v{}", pending.version);

    // 4) 立即以新 exe 拉起子进程并退出：当前进程镜像已被改名成 .old，
    //    原地继续跑的仍是旧版本——不换进程的话，用户重启后看到的还是
    //    旧版界面（旧缺陷）。新实例启动时无标记，直接跳过，不会循环。
    //    注意：新实例插件 setup（CreateMutexW）前必须释放 single-instance
    //    互斥与隐藏窗口，否则被判第二实例自杀退出——升级后「没有自动重启」
    //    的根因（relaunch_app 内部「先 spawn 成功再 destroy」保证顺序）。
    //    参数原样透传（strip_hidden_arg=false）：开机自启静默实例装完更新仍驻托盘。
    relaunch_app(app, false);
}

/// 重启当前进程（以磁盘上的 exe 重新拉起后退出当前进程）。
/// 供两处共用：① updater 自替换成功后接管启动；② 「立即重启」按钮
/// （restart_app 命令，数据目录迁移/更新就绪后重启）。
///
/// `strip_hidden_arg` = 是否剥掉 `--autostart-hidden` 再拉起：
/// - 「立即重启」（用户主动点）传 **true**：开机自启的实例带该参数静默驻托盘，用户
///   从托盘打开使用后点「立即重启」装更新，若原样透传该参数，新进程装完直接隐回
///   托盘——表现为「更新后自动最小化，还得手动再开一次」。剥掉后新进程正常启动，
///   前端 main.ts 的启动逻辑会直接显示主窗口并抢焦点。
/// - 启动期自替换（apply_pending_update）传 **false** 原样透传：开机静默升级的
///   场景下新进程保持静默驻托盘，不弹窗打扰。
///
/// single-instance 插件的 mutex（`x-hub-sim`）与隐藏窗口在插件 setup 时创建，
/// 正常由插件的 `RunEvent::Exit` on_event 销毁。但这里是用 `std::process::exit(0)`
/// 硬退（不触发 RunEvent::Exit / 事件循环），句柄只能靠 OS 在进程终止时回收——
/// 若退出前不释放，spawn 的新实例启动到插件 setup（CreateMutexW）往往先于旧进程
/// 句柄清理完成，被判为「第二实例」自杀退出，升级/重启表现为「没有自动重启」
/// （历史反复出现的现象）。
///
/// 因此顺序必须是：**先 spawn 成功，再 destroy（释放互斥与隐藏窗口），最后退出**：
/// - spawn 成功到新进程真正执行到插件 setup 需要数十毫秒（进程创建 + CRT/运行时
///   初始化），而 destroy 紧跟 spawn 返回之后（微秒级两条 Win32 调用），必然先于
///   新实例的 CreateMutexW——新实例必然成为主实例；
/// - 反过来「先 destroy 再 spawn」一旦 spawn 失败（如被安全软件拦截），本进程
///   继续运行但互斥与窗口已释放：插件判定第二实例依赖「mutex 存在 + 能找到隐藏
///   窗口」，两者都没了之后再手动开一个实例不会被拦截——出现双实例（明确不接受）。
///   所以失败路径绝不触碰 destroy，本进程仍是受保护的唯一主实例。
pub fn relaunch_app(app: &tauri::AppHandle, strip_hidden_arg: bool) {
    // 重启前补一次窗口几何保存：relaunch 走 std::process::exit(0) 硬退，不触发
    // CloseRequested（此前唯一的保存时机）——长期驻留副屏、从不点 × 的用户，
    // config 里存的还是很久以前的坐标，升级/重启后窗口被恢复回老位置（主屏）。
    // 启动早期 apply_pending_update 路径窗口尚未显示，persist 内部 is_visible
    // 守卫直接跳过，不会用默认几何覆盖好数据。
    crate::persist_window_state(app);
    // 直接 exit(0) 不会触发 RunEvent::Exit，service 后端子进程需在此手动停掉，
    // 否则 Node 子进程残留（标准退出路径由 lib.rs RunEvent::Exit → stop_all 兜底）。
    // setup 早期（apply_pending_update 路径）ServiceState 尚未 manage：try_state 判空跳过。
    if app.try_state::<crate::service::ServiceState>().is_some() {
        crate::service::stop_all(app);
    }
    let Ok(exe) = std::env::current_exe() else {
        log::error!("重启失败：无法定位当前 exe");
        return;
    };
    // 当前进程的启动参数原样带给新进程；strip_hidden_arg 时剥掉自启动静默参数
    let mut args: Vec<std::ffi::OsString> = std::env::args_os().skip(1).collect();
    if strip_hidden_arg {
        let before = args.len();
        args.retain(|a| a.as_os_str() != std::ffi::OsStr::new(crate::autostart::HIDDEN_ARG));
        if args.len() != before {
            log::info!("重启已剥掉自启动静默参数，新进程将直接显示主窗口");
        }
    }
    match std::process::Command::new(&exe)
        .args(&args)
        .spawn()
    {
        Ok(_) => {
            // 子进程已创建：此刻释放互斥与隐藏窗口（幂等），保证新实例的
            // CreateMutexW 拿到的是全新互斥、必然成为主实例；随后本进程退出。
            tauri_plugin_single_instance::destroy(app);
            // 托盘图标同样要补发 NIM_DELETE：relaunch 走硬退不触发 RunEvent::Exit，
            // 不清理的话自动重启/手动重启后托盘会留一个悬停才消失的幽灵图标。
            // 新实例按自己的 hwnd+id 重新 NIM_ADD，二者互不影响。
            let _ = app.remove_tray_by_id("main-tray");
            log::info!("已拉起新进程接管启动，当前进程退出");
            std::process::exit(0);
        }
        // 拉起失败（如被安全软件拦截）：互斥与隐藏窗口原样保留，本进程仍是
        // 唯一主实例（不会出现双实例窗口期）；磁盘上 exe 已就位（自替换或本就
        // 该版本），用户下次手动启动即生效。
        Err(e) => {
            log::error!("重启拉起失败（{e}），请手动重启应用");
        }
    }
}

fn remove_pending_file() -> std::io::Result<()> {
    if let Ok(p) = pending_file() {
        let _ = std::fs::remove_file(&p);
    }
    Ok(())
}

/// 跨卷安全移动：同卷走原子 rename；跨卷（数据根与 exe 不同盘）rename 报
/// os error 17「系统无法将文件移到不同的磁盘驱动器」，退化为复制——调用点
/// 已把旧 exe 挪走、目标路径空出，运行中的 exe 不锁定新建文件，复制可成功。
fn move_file(src: &Path, dst: &Path) -> std::io::Result<()> {
    match std::fs::rename(src, dst) {
        Ok(()) => Ok(()),
        Err(rename_err) => std::fs::copy(src, dst).map(|_| ()).map_err(|copy_err| {
            log::warn!("rename 失败（{rename_err}），复制兜底也失败（{copy_err}）");
            copy_err
        }),
    }
}

/// 清理一份待应用更新（zip、解包目录与标记）。
fn discard_pending(pending: &PendingUpdate) {
    if !pending.zip_path.is_empty() {
        let _ = std::fs::remove_file(PathBuf::from(&pending.zip_path));
    }
    if let Ok(root) = updates_root() {
        let _ = std::fs::remove_dir_all(root.join(&pending.version));
    }
    let _ = remove_pending_file();
}

fn exe_file_name_with_old(exe: &Path) -> std::ffi::OsString {
    let mut name = exe.file_name().unwrap_or_default().to_os_string();
    name.push(".old");
    name
}

/// 在解包目录（根或一层）里找 `.exe` 文件；有多个时取体积最大的（防误取只读小工具）。
fn locate_new_exe(dir: &Path) -> Option<PathBuf> {
    let mut best: Option<(PathBuf, u64)> = None;
    let mut consider = |p: &Path| {
        if let Some(name) = p.file_name() {
            let lower = name.to_string_lossy().to_lowercase();
            if lower.ends_with(".exe") && std::fs::metadata(p).map(|m| m.is_file()).unwrap_or(false) {
                let size = std::fs::metadata(p).map(|m| m.len()).unwrap_or(0);
                if best.as_ref().map(|(_, s)| size > *s).unwrap_or(true) {
                    best = Some((p.to_path_buf(), size));
                }
            }
        }
    };
    if let Ok(entries) = std::fs::read_dir(dir) {
        for e in entries.flatten() {
            let p = e.path();
            consider(&p);
            if p.is_dir() {
                if let Ok(inner) = std::fs::read_dir(&p) {
                    for ie in inner.flatten() {
                        consider(&ie.path());
                    }
                }
            }
        }
    }
    best.map(|(p, _)| p)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_pending_camel_case() {
        // download_update 写入的是 camelCase 的 zipPath，读取必须能映射回 zip_path
        let json = serde_json::json!({
            "version": "0.3.1",
            "zipPath": "C:/x/updates/0.3.1/x-hub.zip",
            "portable": false,
        });
        let p: PendingUpdate = serde_json::from_value(json).unwrap();
        assert_eq!(p.version, "0.3.1");
        assert_eq!(p.zip_path, "C:/x/updates/0.3.1/x-hub.zip");
        assert!(!p.portable);
    }

    #[test]
    fn move_file_works_and_overwrites() {
        let dir = std::env::temp_dir().join(format!("xhub-move-test-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();

        // 目标已存在：Windows 上 rename 必败 → 退化复制并覆盖（跨卷场景的等效路径）
        let src = dir.join("src.exe");
        let dst = dir.join("dst.exe");
        std::fs::write(&src, b"new").unwrap();
        std::fs::write(&dst, b"old").unwrap();
        move_file(&src, &dst).unwrap();
        assert_eq!(std::fs::read(&dst).unwrap(), b"new");

        // 目标不存在：rename 直达（同卷主路径）
        let src2 = dir.join("src2.exe");
        let dst2 = dir.join("dst2.exe");
        std::fs::write(&src2, b"v2").unwrap();
        move_file(&src2, &dst2).unwrap();
        assert_eq!(std::fs::read(&dst2).unwrap(), b"v2");
        assert!(!src2.exists());

        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn parses_manifest() {
        let json = serde_json::json!({
            "schemaVersion": 1,
            "version": "0.4.0",
            "minimumUpgradable": "0.1.0",
            "notes": "v0.4.0: 新增更新中心",
            "platforms": {
                "windows-x86_64": {
                    "url": "https://dist/x-hub-0.4.0.zip",
                    "portableUrl": "https://dist/x-hub-0.4.0-portable.zip",
                    "sha256": "abc",
                    "portableSha256": "def",
                    "size": 1024
                }
            }
        });
        let m = parse_manifest(&serde_json::to_vec(&json).unwrap()).unwrap();
        assert_eq!(m.schema_version, 1);
        assert_eq!(m.version, "0.4.0");
        assert_eq!(m.minimum_upgradable, "0.1.0");
        let e = m.platforms.get("windows-x86_64").expect("有平台条目");
        assert_eq!(e.portable_url, "https://dist/x-hub-0.4.0-portable.zip");
    }

    #[test]
    fn rejects_future_schema() {
        let json = serde_json::json!({
            "schemaVersion": 99,
            "version": "0.4.0",
            "platforms": {}
        });
        assert!(parse_manifest(&serde_json::to_vec(&json).unwrap()).is_err());
    }

    #[test]
    fn rejects_missing_version() {
        let json = serde_json::json!({ "schemaVersion": 1, "platforms": {} });
        assert!(parse_manifest(&serde_json::to_vec(&json).unwrap()).is_err());
    }

    #[test]
    fn is_newer_guards_jump() {
        let mut m = UpdateManifest::default();
        m.version = "0.4.0".to_string();
        // 正常更新
        assert!(is_newer(&m, "0.3.0"));
        // 同版本/低版本不更新
        assert!(!is_newer(&m, "0.4.0"));
        assert!(!is_newer(&m, "0.5.0"));
        // 跳级保护：当前低于可升级下限
        m.minimum_upgradable = "0.3.0".to_string();
        assert!(!is_newer(&m, "0.2.0"));
        assert!(is_newer(&m, "0.3.0"));
    }

    #[test]
    fn locate_exe_picks_largest() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("config.json"), "{}").unwrap();
        std::fs::write(dir.path().join("x-hub.exe"), vec![0u8; 100]).unwrap();
        std::fs::write(dir.path().join("helper.exe"), vec![0u8; 10]).unwrap();
        let found = locate_new_exe(dir.path()).unwrap();
        assert_eq!(found.file_name().unwrap().to_string_lossy(), "x-hub.exe");
    }

    #[test]
    fn locate_exe_finds_nested() {
        let dir = tempfile::tempdir().unwrap();
        let sub = dir.path().join("res");
        std::fs::create_dir_all(&sub).unwrap();
        std::fs::write(sub.join("x-hub.exe"), vec![0u8; 50]).unwrap();
        let found = locate_new_exe(dir.path()).unwrap();
        assert_eq!(found.file_name().unwrap().to_string_lossy(), "x-hub.exe");
    }
}