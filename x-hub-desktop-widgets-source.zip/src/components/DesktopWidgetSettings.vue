<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { getCurrentWindow } from '@tauri-apps/api/window'
import { isTauri, tauriApi, type DesktopWidgetConfig, type WidgetCategory } from '../api/tauri'
import { Palette, Plus, Save, X } from 'lucide-vue-next'
const config = ref<DesktopWidgetConfig | null>(null)
const busy = ref(false)
const message = ref('')
async function load() { config.value = await tauriApi.getDesktopWidgetConfig() }
function addCategory(kind: 'categories' | 'urgencies') {
  if (!config.value) return
  const list = config.value[kind]
  const id = `${kind === 'categories' ? 'cat' : 'urg'}-${Date.now()}`
  list.push({ id, name: kind === 'categories' ? '新类别' : '新紧急程度', color: '#5388e8' } satisfies WidgetCategory)
}
function removeCategory(kind: 'categories' | 'urgencies', id: string) {
  if (!config.value) return
  if (kind === 'categories' && config.value.categories.length <= 1) { message.value = '至少保留一个日程类别'; return }
  if (kind === 'urgencies' && config.value.urgencies.length <= 1) { message.value = '至少保留一个紧急程度'; return }
  config.value[kind] = config.value[kind].filter(x => x.id !== id)
}
async function save() {
  if (!config.value || busy.value) return
  busy.value = true; message.value = ''
  try {
    // Fetch the newest snapshot before saving display settings so concurrent calendar edits survive.
    const latest = await tauriApi.getDesktopWidgetConfig()
    latest.appearance = config.value.appearance
    latest.categories = config.value.categories
    latest.urgencies = config.value.urgencies
    await tauriApi.saveDesktopWidgetConfig(latest)
    config.value = latest
    message.value = '设置已保存，两个组件已同步。'
  } catch (e) { message.value = `保存失败：${String(e)}` }
  finally { busy.value = false }
}
async function close() { if (isTauri()) await getCurrentWindow().close() }
onMounted(load)
</script>

<template>
  <main v-if="config" class="dws-page">
    <header class="dws-header"><div class="dws-title"><Palette :size="19"/><div><h1>桌面组件设置</h1><p>日程表与待办清单共用背景、透明度和字体设置</p></div></div><button class="dws-close" title="关闭" @click="close"><X :size="18"/></button></header>
    <div class="dws-content">
      <section class="dws-panel"><h2>共同外观</h2>
        <div class="dws-grid">
          <label>背景颜色<input v-model="config.appearance.background_color" type="color" /></label>
          <label>背景透明度 <strong>{{ Math.round(config.appearance.background_opacity * 100) }}%</strong><input v-model.number="config.appearance.background_opacity" type="range" min="0.15" max="1" step="0.05" /></label>
          <label>文字颜色<input v-model="config.appearance.text_color" type="color" /></label>
          <label>边框颜色<input v-model="config.appearance.border_color" type="color" /></label>
          <label>工作日文字颜色<input v-model="config.appearance.weekday_color" type="color" /></label>
          <label>周六日文字颜色<input v-model="config.appearance.weekend_color" type="color" /></label>
          <label>今日突出颜色<input v-model="config.appearance.today_color" type="color" /></label>
          <label>字体大小 <strong>{{ config.appearance.font_size }} px</strong><input v-model.number="config.appearance.font_size" type="range" min="9" max="24" step="1" /></label>
          <label class="dws-wide">字体名称<input v-model="config.appearance.font_family" placeholder="例如 Microsoft YaHei、Segoe UI" /></label>
        </div>
      </section>
      <section class="dws-panel"><div class="dws-section-title"><h2>日程类别与颜色</h2><button @click="addCategory('categories')"><Plus :size="14"/> 添加类别</button></div>
        <div v-for="c in config.categories" :key="c.id" class="dws-category"><input v-model="c.name" aria-label="类别名称" maxlength="40"/><input v-model="c.color" type="color" aria-label="类别颜色"/><span class="dws-chip" :style="{backgroundColor:c.color}">{{ c.name || '预览' }}</span><button class="dws-remove" @click="removeCategory('categories', c.id)">删除</button></div>
      </section>
      <section class="dws-panel"><div class="dws-section-title"><h2>待办紧急程度与颜色</h2><button @click="addCategory('urgencies')"><Plus :size="14"/> 添加等级</button></div>
        <div v-for="c in config.urgencies" :key="c.id" class="dws-category"><input v-model="c.name" aria-label="紧急程度名称" maxlength="40"/><input v-model="c.color" type="color" aria-label="紧急程度颜色"/><span class="dws-chip" :style="{backgroundColor:c.color}">{{ c.name || '预览' }}</span><button class="dws-remove" @click="removeCategory('urgencies', c.id)">删除</button></div>
      </section>
      <p class="dws-note">锁定、尺寸与位置分别保存在日程组件和待办组件的布局配置中。数据文件位于便携版 EXE 同目录的 <code>data\desktop_widgets.json</code>。</p>
    </div>
    <footer class="dws-footer"><span role="status">{{ message }}</span><button class="dws-save" :disabled="busy" @click="save"><Save :size="15"/> {{ busy ? '保存中…' : '保存设置' }}</button></footer>
  </main>
  <main v-else class="dws-loading">正在读取桌面组件设置…</main>
</template>

<style scoped>
.dws-page{height:100vh;display:flex;flex-direction:column;background:var(--bg-page-surface);color:var(--text-1);font-size:13px}.dws-header{display:flex;align-items:center;justify-content:space-between;padding:18px 22px;border-bottom:1px solid var(--border-soft);flex-shrink:0}.dws-title{display:flex;align-items:center;gap:12px}.dws-title svg{color:var(--brand-500)}.dws-title h1{font-size:18px;margin:0 0 4px;font-weight:700}.dws-title p{margin:0;color:var(--text-3);font-size:12px}.dws-close{border:0;background:transparent;color:var(--text-3);padding:7px;border-radius:7px;cursor:pointer}.dws-close:hover{background:var(--bg-card-soft)}.dws-content{padding:18px 22px;overflow:auto;display:grid;gap:14px}.dws-panel{background:var(--bg-card-solid);border:1px solid var(--border-soft);border-radius:12px;padding:15px}.dws-panel h2{font-size:14px;margin:0 0 13px;font-weight:700}.dws-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px 18px}.dws-grid label{display:grid;grid-template-columns:1fr auto;gap:6px;align-items:center;color:var(--text-2)}.dws-grid input[type=color]{width:40px;height:26px;border:1px solid var(--border-soft);padding:1px;border-radius:6px;background:transparent}.dws-grid input[type=range]{grid-column:1/-1;width:100%;accent-color:var(--brand-500)}.dws-grid input:not([type=color]):not([type=range]){grid-column:1/-1;width:100%;box-sizing:border-box;background:var(--input-bg);border:1px solid var(--border-soft);border-radius:7px;padding:8px;color:var(--text-1)}.dws-wide{grid-column:1/-1}.dws-section-title{display:flex;align-items:center;justify-content:space-between;margin-bottom:11px}.dws-section-title h2{margin:0}.dws-section-title button{display:flex;align-items:center;gap:5px;border:1px solid var(--border-soft);background:var(--bg-card-soft);color:var(--text-1);border-radius:7px;padding:6px 9px;cursor:pointer}.dws-category{display:grid;grid-template-columns:minmax(100px,1fr) 40px minmax(70px,120px) 45px;gap:9px;align-items:center;margin-top:8px}.dws-category>input:first-child{min-width:0;border:1px solid var(--border-soft);border-radius:6px;background:var(--input-bg);color:var(--text-1);padding:7px 8px}.dws-category input[type=color]{width:38px;height:27px;padding:1px;border:1px solid var(--border-soft);border-radius:6px;background:transparent}.dws-chip{font-size:11px;color:white;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:4px 7px;border-radius:5px}.dws-remove{border:0;background:transparent;color:var(--text-3);cursor:pointer}.dws-remove:hover{color:#e25555}.dws-note{margin:0 3px;color:var(--text-3);font-size:12px;line-height:1.6}.dws-footer{border-top:1px solid var(--border-soft);padding:12px 22px;display:flex;align-items:center;justify-content:space-between;gap:15px;flex-shrink:0;color:var(--text-3);font-size:12px}.dws-save{display:flex;align-items:center;gap:7px;background:var(--brand-500);color:white;border:0;border-radius:8px;padding:9px 14px;cursor:pointer}.dws-save:disabled{opacity:.5}.dws-loading{padding:24px;color:var(--text-2)}
</style>
