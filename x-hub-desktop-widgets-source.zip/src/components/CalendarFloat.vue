<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { getCurrentWindow } from '@tauri-apps/api/window'
import { listen } from '@tauri-apps/api/event'
import { CalendarDays, LockKeyhole, LockKeyholeOpen, Plus, X } from 'lucide-vue-next'
import { isTauri, tauriApi, type CalendarEvent, type DesktopWidgetConfig, type Todo } from '../api/tauri'
import { useStore } from '../stores/workbench'

const store = useStore()
const label = 'calendar-float'
const appWindow = isTauri() ? getCurrentWindow() : null
const config = ref<DesktopWidgetConfig | null>(null)
const now = ref(new Date())
let tick: ReturnType<typeof setInterval> | null = null
let unlistenConfig: (() => void) | null = null
let unlistenTodos: (() => void) | null = null
const locked = computed(() => config.value?.calendar.locked ?? false)

function keyOf(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
function parseKey(key: string) {
  const [y, m, d] = key.split('-').map(Number)
  return new Date(y, m - 1, d, 12, 0, 0, 0)
}
const days = computed(() => {
  const base = new Date(now.value.getFullYear(), now.value.getMonth(), now.value.getDate(), 12)
  base.setDate(base.getDate() - ((base.getDay() + 6) % 7))
  return Array.from({ length: 14 }, (_, i) => {
    const date = new Date(base)
    date.setDate(base.getDate() + i)
    return { key: keyOf(date), day: date.getDate(), date, today: keyOf(date) === keyOf(now.value), weekend: date.getDay() === 0 || date.getDay() === 6 }
  })
})
const monthLabel = computed(() => {
  const a = days.value[0]?.date
  const b = days.value[13]?.date
  return a && b ? (a.getMonth() === b.getMonth() ? `${a.getFullYear()}年${a.getMonth() + 1}月` : `${a.getMonth() + 1}月 · ${b.getMonth() + 1}月`) : ''
})
function categoryOf(ev: CalendarEvent) {
  return config.value?.categories.find(c => c.id === ev.category_id) ?? config.value?.categories[0]
}
function tasksFor(key: string): Todo[] {
  return store.state.todos.filter(t => t.parent_id == null && t.due_at != null && keyOf(new Date(t.due_at)) === key)
    .sort((a, b) => Number(a.done) - Number(b.done) || b.priority - a.priority || b.created_at.localeCompare(a.created_at))
}
function eventsFor(key: string) { return (config.value?.events ?? []).filter(e => e.date === key) }
function urgencyColor(priority: number) {
  const index = Math.max(0, Math.min(2, priority))
  return config.value?.urgencies[index]?.color ?? ['#8b95a7', '#e7a23b', '#e25555'][index]
}
function hexToRgba(hex: string, alpha: number) {
  const s = hex.replace('#', '').trim()
  if (!/^[0-9a-fA-F]{6}$/.test(s)) return `rgba(32,35,43,${alpha})`
  return `rgba(${parseInt(s.slice(0, 2), 16)},${parseInt(s.slice(2, 4), 16)},${parseInt(s.slice(4, 6), 16)},${alpha})`
}
const widgetStyle = computed(() => {
  const a = config.value?.appearance
  return a ? {
    backgroundColor: hexToRgba(a.background_color, a.background_opacity),
    color: a.text_color,
    borderColor: hexToRgba(a.border_color, Math.max(0.35, a.background_opacity)),
    fontFamily: `${a.font_family || 'Microsoft YaHei'}, sans-serif`,
    fontSize: `${a.font_size}px`,
    '--weekend-color': a.weekend_color,
    '--weekday-color': a.weekday_color,
    '--today-color': a.today_color,
  } : {}
})
async function loadConfig() {
  if (!isTauri()) return
  try { config.value = await tauriApi.getDesktopWidgetConfig() } catch { /* 显示默认样式 */ }
}

const menu = ref<{ x: number; y: number; date: string } | null>(null)
const modal = ref<{ kind: 'event' | 'todo'; date: string } | null>(null)
const titleInput = ref('')
const categoryId = ref('meeting')
const urgencyId = ref('normal')
function openDateMenu(e: MouseEvent, date: string) {
  e.preventDefault(); e.stopPropagation()
  menu.value = { x: Math.max(4, Math.min(e.clientX, window.innerWidth - 180)), y: Math.max(4, Math.min(e.clientY, window.innerHeight - 100)), date }
}
function startCreate(kind: 'event' | 'todo') {
  if (!menu.value) return
  modal.value = { kind, date: menu.value.date }
  titleInput.value = ''
  categoryId.value = config.value?.categories[0]?.id ?? 'meeting'
  urgencyId.value = config.value?.urgencies[0]?.id ?? 'normal'
  menu.value = null
}
async function saveNew() {
  const title = titleInput.value.trim()
  if (!title || !modal.value) return
  if (modal.value.kind === 'event') {
    // Reload before modifying events so a settings window opened earlier cannot overwrite newer entries.
    const cfg = await tauriApi.getDesktopWidgetConfig()
    const ev: CalendarEvent = { id: `event-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, date: modal.value.date, title, category_id: categoryId.value, created_at: new Date().toISOString() }
    const next = { ...cfg, events: [...cfg.events, ev] }
    await tauriApi.saveDesktopWidgetConfig(next)
    config.value = next
  } else {
    const todo = await store.createTodo(title)
    const urgencyIndex = Math.max(0, (config.value?.urgencies.findIndex(x => x.id === urgencyId.value) ?? 0))
    await store.updateTodo(todo.id, todo.title, Math.min(2, urgencyIndex))
    const date = parseKey(modal.value.date)
    date.setHours(9, 0, 0, 0)
    await store.scheduleTodo(todo.id, date.getTime(), null)
    await store.refreshTodos()
  }
  modal.value = null
}
async function removeEvent(ev: CalendarEvent) {
  const cfg = await tauriApi.getDesktopWidgetConfig()
  const next = { ...cfg, events: cfg.events.filter(x => x.id !== ev.id) }
  await tauriApi.saveDesktopWidgetConfig(next)
  config.value = next
}
const eventMenu = ref<{ x: number; y: number; event: CalendarEvent } | null>(null)
function openEventMenu(e: MouseEvent, ev: CalendarEvent) { e.preventDefault(); e.stopPropagation(); eventMenu.value = { x: e.clientX, y: e.clientY, event: ev } }
async function toggleLocked() {
  if (!config.value) return
  const next = !locked.value
  try { await tauriApi.setDesktopWidgetLocked(label, next); config.value.calendar.locked = next } catch { /* 保持旧状态 */ }
}
async function closeWidget() { if (isTauri()) await tauriApi.setDesktopWidgetVisible(label, false) }
const DRAG_THRESHOLD = 4
let dragPending: { x: number; y: number } | null = null
function onMouseDown(e: MouseEvent) {
  if (!appWindow || e.button !== 0 || locked.value) return
  const target = e.target as HTMLElement
  if (target.closest('button, input, select, textarea, .cf-cell, .cf-menu, .cf-modal')) return
  dragPending = { x: e.screenX, y: e.screenY }
}
function onMouseMove(e: MouseEvent) {
  if (!dragPending || !appWindow || locked.value) return
  const dx = e.screenX - dragPending.x, dy = e.screenY - dragPending.y
  if (dx * dx + dy * dy >= DRAG_THRESHOLD * DRAG_THRESHOLD) { dragPending = null; void appWindow.startDragging() }
}
function onDragEnd() { dragPending = null }
type ResizeDirection = 'East' | 'North' | 'NorthEast' | 'NorthWest' | 'South' | 'SouthEast' | 'SouthWest' | 'West'
const RESIZE_DIRECTIONS: ResizeDirection[] = ['North', 'South', 'East', 'West', 'NorthEast', 'NorthWest', 'SouthEast', 'SouthWest']
function onResizeStart(e: MouseEvent, dir: ResizeDirection) {
  if (!appWindow || locked.value || e.button !== 0) return
  e.preventDefault(); e.stopPropagation(); void appWindow.startResizeDragging(dir)
}

onMounted(async () => {
  document.documentElement.dataset.calendarFloat = ''
  await store.loadInitialData(); await loadConfig()
  tick = setInterval(() => { const next = new Date(); if (keyOf(next) !== keyOf(now.value)) now.value = next }, 30_000)
  if (isTauri()) {
    unlistenConfig = await listen('desktop-widget-config-changed', () => { void loadConfig() })
    unlistenTodos = await listen('todos-changed', () => { void store.refreshTodos() })
  }
})
onBeforeUnmount(() => { if (tick) clearInterval(tick); unlistenConfig?.(); unlistenTodos?.(); delete document.documentElement.dataset.calendarFloat })
</script>

<template>
  <div class="cf-root" :style="widgetStyle" @mousedown="onMouseDown" @mousemove="onMouseMove" @mouseup="onDragEnd" @mouseleave="onDragEnd" @click.self="menu = null">
    <header class="cf-header" :class="{ locked }">
      <div class="cf-heading"><CalendarDays :size="15"/><span>双周日程</span><span class="cf-month">{{ monthLabel }}</span></div>
      <div class="cf-controls">
        <button class="cf-btn" :title="locked ? '解锁组件' : '锁定位置和大小'" @click="toggleLocked"><LockKeyhole v-if="locked" :size="14"/><LockKeyholeOpen v-else :size="14"/></button>
        <button class="cf-btn" title="关闭组件" @click="closeWidget"><X :size="14"/></button>
      </div>
    </header>
    <div class="cf-weekdays">
      <span v-for="d in ['一','二','三','四','五','六','日']" :key="d" :class="{ weekend: d === '六' || d === '日' }">{{ d }}</span>
    </div>
    <div class="cf-grid">
      <div v-for="day in days" :key="day.key" class="cf-cell" :class="{ today: day.today, weekend: day.weekend }" @contextmenu="openDateMenu($event, day.key)" :title="`${day.key} · 右键新建日程或待办`">
        <div class="cf-daynum"><span>{{ day.day }}</span><small v-if="day.today">今天</small></div>
        <div class="cf-items">
          <button v-for="ev in eventsFor(day.key).slice(0, 2)" :key="ev.id" class="cf-event" :style="{ backgroundColor: categoryOf(ev)?.color ?? '#5388e8' }" :title="ev.title" @contextmenu="openEventMenu($event, ev)">{{ ev.title }}</button>
          <div v-for="todo in tasksFor(day.key).slice(0, 2)" :key="'t'+todo.id" class="cf-task" :class="{ done: todo.done }" :style="{ borderLeftColor: urgencyColor(todo.priority) }" :title="todo.title" @contextmenu="openDateMenu($event, day.key)">
            <input type="checkbox" :checked="todo.done" :style="{ accentColor: urgencyColor(todo.priority) }" :aria-label="todo.done ? '取消完成' : '标记完成'" @click.stop @change="store.toggleTodo(todo.id)" />
            <span>{{ todo.title }}</span>
          </div>
        </div>
        <button class="cf-add" title="新建日程或待办" @click.stop="openDateMenu($event, day.key)"><Plus :size="11"/></button>
      </div>
    </div>
    <div v-if="menu" class="cf-menu" :style="{ left: `${menu.x}px`, top: `${menu.y}px` }" @click.stop>
      <button @click="startCreate('event')">新建日程</button><button @click="startCreate('todo')">新建待办</button>
    </div>
    <div v-if="eventMenu" class="cf-menu" :style="{ left: `${eventMenu.x}px`, top: `${eventMenu.y}px` }" @click.stop>
      <button @click="removeEvent(eventMenu.event); eventMenu = null">删除日程</button>
    </div>
    <div v-if="modal" class="cf-backdrop" @click.self="modal = null">
      <form class="cf-modal" @submit.prevent="saveNew">
        <h3>{{ modal.kind === 'event' ? '新建日程' : '新建待办' }}</h3><p>{{ modal.date }}</p>
        <input v-model="titleInput" autofocus maxlength="200" :placeholder="modal.kind === 'event' ? '输入日程名称' : '输入待办内容'" />
        <label v-if="modal.kind === 'event'">日程类别
          <select v-model="categoryId"><option v-for="c in config?.categories ?? []" :key="c.id" :value="c.id">{{ c.name }}</option></select>
        </label>
        <label v-else>紧急程度
          <select v-model="urgencyId"><option v-for="c in config?.urgencies ?? []" :key="c.id" :value="c.id">{{ c.name }}</option></select>
        </label>
        <div class="cf-modal-actions"><button type="button" @click="modal = null">取消</button><button type="submit" :disabled="!titleInput.trim()">保存</button></div>
      </form>
    </div>
    <template v-if="appWindow && !locked"><div v-for="dir in RESIZE_DIRECTIONS" :key="dir" class="cf-rz" :class="'cf-rz-'+dir.toLowerCase()" @mousedown="onResizeStart($event, dir)"></div></template>
  </div>
</template>

<style scoped>
.cf-root{position:relative;box-sizing:border-box;width:100%;height:100%;overflow:hidden;padding:10px;border:1px solid var(--widget-border,#5b6472);border-radius:12px;backdrop-filter:blur(14px);display:flex;flex-direction:column;user-select:none}
.cf-header{display:flex;justify-content:space-between;align-items:center;cursor:move;flex-shrink:0;margin-bottom:7px}.cf-header.locked{cursor:default}.cf-heading,.cf-controls{display:flex;align-items:center;gap:7px}.cf-heading{font-weight:700}.cf-month{font-size:.88em;opacity:.75;font-weight:500;margin-left:6px}.cf-btn{border:0;background:transparent;color:inherit;opacity:.82;width:26px;height:26px;border-radius:6px;display:grid;place-items:center;cursor:pointer}.cf-btn:hover{background:#ffffff22;opacity:1}
.cf-weekdays,.cf-grid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:4px}.cf-weekdays{flex-shrink:0;margin-bottom:4px;text-align:center;font-size:.85em;opacity:.85;color:var(--weekday-color)}.cf-weekdays .weekend{color:var(--weekend-color)}.cf-grid{flex:1;min-height:0;grid-template-rows:repeat(2,minmax(0,1fr))}.cf-cell{position:relative;min-width:0;min-height:0;overflow:hidden;border:1px solid #ffffff20;border-radius:7px;padding:4px;background:#ffffff05}.cf-cell.weekend{background:#ffffff0a}.cf-cell.today{border-color:var(--today-color);box-shadow:inset 0 0 0 1px var(--today-color);background:#719df51a}.cf-daynum{display:flex;align-items:center;justify-content:space-between;color:var(--weekday-color);font-size:.92em;font-weight:700;margin-bottom:3px}.cf-cell.weekend .cf-daynum{color:var(--weekend-color)}.cf-cell.today .cf-daynum{color:var(--today-color)}.cf-daynum small{font-size:.7em;white-space:nowrap}.cf-items{display:flex;flex-direction:column;gap:2px;overflow:hidden}.cf-event{display:block;border:0;border-radius:3px;color:#fff;font-size:.76em;line-height:1.3;padding:2px 3px;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:default}.cf-task{display:flex;gap:3px;align-items:center;min-width:0;border-left:2px solid transparent;padding-left:3px;font-size:.74em;line-height:1.3}.cf-task input{width:11px;height:11px;flex-shrink:0;margin:0;accent-color:var(--today-color)}.cf-task span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cf-task.done{opacity:.48}.cf-task.done span{text-decoration:line-through}.cf-add{position:absolute;right:3px;bottom:3px;width:16px;height:16px;padding:0;border:0;border-radius:4px;display:grid;place-items:center;background:#ffffff12;color:inherit;opacity:0;cursor:pointer}.cf-cell:hover .cf-add{opacity:.8}.cf-menu{position:fixed;z-index:1000;min-width:142px;padding:4px;background:#222630f5;border:1px solid #ffffff33;border-radius:8px;box-shadow:0 8px 28px #0007;display:grid;gap:2px;color:#fff}.cf-menu button{border:0;border-radius:5px;background:transparent;color:inherit;text-align:left;padding:7px 9px;cursor:pointer}.cf-menu button:hover{background:#ffffff20}.cf-backdrop{position:fixed;inset:0;z-index:1200;display:grid;place-items:center;background:#0006}.cf-modal{width:min(330px,calc(100% - 30px));padding:16px;border-radius:12px;background:#262a34;color:#f4f5f7;box-shadow:0 12px 40px #0008;display:grid;gap:10px}.cf-modal h3{margin:0;font-size:1.05em}.cf-modal p{margin:0;font-size:.85em;opacity:.65}.cf-modal input,.cf-modal select{width:100%;box-sizing:border-box;margin-top:4px;padding:8px;border:1px solid #ffffff30;border-radius:7px;background:#171a21;color:inherit}.cf-modal label{font-size:.84em}.cf-modal-actions{display:flex;justify-content:flex-end;gap:8px}.cf-modal-actions button{border:0;border-radius:7px;padding:7px 12px;color:inherit;background:#ffffff18;cursor:pointer}.cf-modal-actions button[type=submit]{background:#4b78dd}.cf-modal-actions button:disabled{opacity:.4}.cf-rz{position:absolute;z-index:50}.cf-rz-north,.cf-rz-south{left:8px;right:8px;height:5px}.cf-rz-north{top:0;cursor:ns-resize}.cf-rz-south{bottom:0;cursor:ns-resize}.cf-rz-east,.cf-rz-west{top:8px;bottom:8px;width:5px}.cf-rz-east{right:0;cursor:ew-resize}.cf-rz-west{left:0;cursor:ew-resize}.cf-rz-northeast,.cf-rz-northwest,.cf-rz-southeast,.cf-rz-southwest{width:13px;height:13px}.cf-rz-northeast{right:0;top:0;cursor:nesw-resize}.cf-rz-northwest{left:0;top:0;cursor:nwse-resize}.cf-rz-southeast{right:0;bottom:0;cursor:nwse-resize}.cf-rz-southwest{left:0;bottom:0;cursor:nesw-resize}
</style>
