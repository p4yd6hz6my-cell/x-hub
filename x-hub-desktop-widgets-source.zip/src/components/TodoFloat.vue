<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, provide, ref } from 'vue'
import { getCurrentWindow } from '@tauri-apps/api/window'
import { listen } from '@tauri-apps/api/event'
import { ListTodo, LockKeyhole, LockKeyholeOpen, X } from 'lucide-vue-next'
import { isTauri, tauriApi, type DesktopWidgetConfig, type Todo } from '../api/tauri'
import { useStore } from '../stores/workbench'
import { useTheme } from '../composables/useTheme'
import { parseTodoItems } from '../utils/todoParse'
import { comparePinnedFirst } from '../utils/todoSchedule'
import { useTodoChildren } from '../composables/useTodoChildren'
import TodoRow from './TodoRow.vue'

const store = useStore()

// ---- 子待办支持（与工作台待办卡共用 TodoRow）----
// 不提供 todoOpenSchedule：浮窗无排期弹层，TodoRow 内日期徽标转只读、隐藏「日期」按钮；
// 不提供 todoDragStart：顶级行按下仍走窗口拖动，子待办组内拖拽由 TodoRow 自带。
const childrenMap = useTodoChildren()
provide('todoChildren', childrenMap)
provide('todoRemoveTodo', (t: Todo) => {
  // 浮窗无 toast 撤销体系，直接删（后端级联删子待办）
  void store.deleteTodo(t.id)
})

// 从窗口 label 取浮窗标识（todo-float），用于置顶切换
const floatLabel = isTauri() ? getCurrentWindow().label : 'todo-float'
const widgetConfig = ref<DesktopWidgetConfig | null>(null)
const locked = computed(() => widgetConfig.value?.todo.locked ?? false)

function hexToRgba(hex: string, alpha: number) {
  const s = hex.replace('#', '').trim()
  if (!/^[0-9a-fA-F]{6}$/.test(s)) return `rgba(32,35,43,${alpha})`
  return `rgba(${parseInt(s.slice(0, 2), 16)},${parseInt(s.slice(2, 4), 16)},${parseInt(s.slice(4, 6), 16)},${alpha})`
}
const widgetStyle = computed(() => {
  const a = widgetConfig.value?.appearance
  return a ? {
    backgroundColor: hexToRgba(a.background_color, a.background_opacity),
    color: a.text_color,
    borderColor: hexToRgba(a.border_color, Math.max(0.35, a.background_opacity)),
    fontFamily: `${a.font_family || 'Microsoft YaHei'}, sans-serif`,
    fontSize: `${a.font_size}px`,
    '--todo-pri-default': hexToRgba(widgetConfig.value?.urgencies[0]?.color ?? '#8b95a7', 0.24),
    '--c-yellow-soft': hexToRgba(widgetConfig.value?.urgencies[1]?.color ?? '#e7a23b', 0.24),
    '--c-red-soft': hexToRgba(widgetConfig.value?.urgencies[2]?.color ?? '#e25555', 0.24),
  } : {}
})

async function loadWidgetConfig() {
  if (!isTauri()) return
  try { widgetConfig.value = await tauriApi.getDesktopWidgetConfig() } catch { /* 使用默认主题 */ }
}
async function toggleLocked() {
  const next = !locked.value
  try {
    await tauriApi.setDesktopWidgetLocked(floatLabel, next)
    if (widgetConfig.value) widgetConfig.value.todo.locked = next
  } catch { /* 保持当前状态 */ }
}

// 标记为待办浮窗：body 透明，只显示卡片本体
document.documentElement.dataset.todoFloat = ''
useTheme()

let unlisten: (() => void) | null = null
let unlistenConfig: (() => void) | null = null

onMounted(async () => {
  await store.loadInitialData()
  await loadWidgetConfig()
  if (isTauri()) {
    unlisten = await listen('todos-changed', () => { void store.refreshTodos() })
    unlistenConfig = await listen('desktop-widget-config-changed', () => { void loadWidgetConfig() })
  }
})

onBeforeUnmount(() => {
  unlisten?.()
  unlistenConfig?.()
})

const input = ref('')

// 与待办卡片同一排序规则的平铺版：置顶条目浮到最前（浮窗不分组），
// 其余手动拖过的（sort_order）优先，再按创建时间倒序
const pendingTodos = computed(() =>
  store.state.todos.filter((t) => !t.done && t.parent_id == null).sort(comparePinnedFirst),
)
// 待办浮窗保留最近完成的两项（较旧的那条在前），其余完成项不显示但仍保存在数据库。
const recentCompletedTodos = computed(() => store.state.todos
  .filter(t => t.done && t.parent_id == null)
  .sort((a, b) => (Date.parse(a.completed_at ?? a.updated_at) || 0) - (Date.parse(b.completed_at ?? b.updated_at) || 0))
  .slice(-2))

async function onAdd() {
  const v = input.value.trim()
  if (!v) return
  // 支持「1. a 2. b 3. c」这类序号列表一次拆成多条；非序号文本原样一条
  await Promise.all(parseTodoItems(v).map((title) => store.createTodo(title)))
  input.value = ''
}

// 回车提交（Shift/组合键不拦截）；IME 组合期间不提交，避免误触
function onAddKeydown(e: KeyboardEvent) {
  if (e.isComposing) return
  if (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return
  e.preventDefault()
  void onAdd()
}

async function onClose() {
  if (isTauri()) await tauriApi.setDesktopWidgetVisible(floatLabel, false)
}

// 窗口拖动
const appWindow = isTauri() ? getCurrentWindow() : null
const DRAG_THRESHOLD = 4
let dragPending: { x: number; y: number } | null = null

function onMouseDown(e: MouseEvent) {
  if (!appWindow || e.button !== 0 || locked.value) return
  const target = e.target as HTMLElement
  // 子待办行是行内交互区（勾选/编辑/组内拖拽），让给 TodoRow；编辑框同理不触发窗口拖动
  if (target.closest('button, input, textarea, .todo-row.sub')) return
  dragPending = { x: e.screenX, y: e.screenY }
}
function onMouseMove(e: MouseEvent) {
  if (!dragPending || !appWindow || locked.value) return
  const dx = e.screenX - dragPending.x
  const dy = e.screenY - dragPending.y
  if (dx * dx + dy * dy >= DRAG_THRESHOLD * DRAG_THRESHOLD) {
    dragPending = null
    void appWindow.startDragging()
  }
}
function onDragEnd() {
  dragPending = null
}

// ---- 边缘拖拽改变窗口大小 ----
// 无边框窗口没有系统缩放边，用 8 个隐形边缘区手动触发系统级 resize；
// stopPropagation 拦掉冒泡，避免同时进入「拖动窗口」流程
// 与 @tauri-apps/api window 的 ResizeDirection 同构（该类型未导出，此处本地声明）
type ResizeDirection = 'East' | 'North' | 'NorthEast' | 'NorthWest' | 'South' | 'SouthEast' | 'SouthWest' | 'West'
const RESIZE_DIRECTIONS: ResizeDirection[] = [
  'North',
  'South',
  'East',
  'West',
  'NorthEast',
  'NorthWest',
  'SouthEast',
  'SouthWest',
]

function onResizeStart(e: MouseEvent, dir: ResizeDirection) {
  if (!appWindow || locked.value || e.button !== 0) return
  e.preventDefault()
  e.stopPropagation()
  void appWindow.startResizeDragging(dir)
}
</script>

<template>
  <div
    class="tf-root"
    :style="widgetStyle"
    @mousedown="onMouseDown"
    @mousemove="onMouseMove"
    @mouseup="onDragEnd"
    @mouseleave="onDragEnd"
  >
    <header class="tf-header" :class="{ locked }">
      <h3 class="tf-title">
        <ListTodo :size="14" :stroke-width="2" aria-hidden="true" />
        <span>待办</span>
      </h3>
      <div class="tf-controls">
        <button
          class="tf-btn"
          :class="{ active: locked }"
          :title="locked ? '解锁：允许移动和缩放' : '锁定：禁止移动和缩放'"
          type="button"
          @click="toggleLocked"
        >
          <LockKeyhole v-if="locked" :size="13" :stroke-width="2" />
          <LockKeyholeOpen v-else :size="13" :stroke-width="2" />
        </button>
        <button class="tf-btn tf-close" title="关闭" aria-label="关闭" @click="onClose">
          <X :size="13" :stroke-width="2" />
        </button>
      </div>
    </header>

    <div class="tf-add">
      <textarea
        v-model="input"
        class="tf-input"
        rows="1"
        placeholder="添加待办，回车确认"
        aria-label="添加待办"
        @keydown.enter="onAddKeydown"
      ></textarea>
    </div>

    <div class="tf-body">
      <div v-if="pendingTodos.length === 0 && recentCompletedTodos.length === 0" class="tf-empty">
        <p>暂无待办</p>
      </div>
      <div v-else class="tf-list">
        <div v-if="recentCompletedTodos.length" class="tf-section-label">最近完成</div>
        <TodoRow v-for="t in recentCompletedTodos" :key="'done-'+t.id" :todo="t" />
        <div v-if="pendingTodos.length && recentCompletedTodos.length" class="tf-section-label">未完成</div>
        <!-- 复用 TodoRow 的 checkbox 和完成状态；数据仍由 x-hub todos 表统一维护。 -->
        <TodoRow v-for="t in pendingTodos" :key="t.id" :todo="t" />
      </div>
    </div>

    <!-- 8 方向隐形缩放边缘（仅 Tauri 窗口内渲染） -->
    <template v-if="appWindow && !locked">
      <div
        v-for="dir in RESIZE_DIRECTIONS"
        :key="dir"
        class="rz"
        :class="'rz-' + dir.toLowerCase()"
        @mousedown="onResizeStart($event, dir)"
      ></div>
    </template>
  </div>
</template>

<style scoped>
.tf-root {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  padding: 10px;
  box-sizing: border-box;
  -webkit-app-region: no-drag;
  font-size: calc(1rem * var(--fs-todo, 1));
  position: relative;
}
/* 缩放边缘区：边 6px、角 14px，叠加在内容之上但平时不可见 */
.rz {
  position: absolute;
  z-index: 60;
}
.rz-north {
  top: 0;
  left: 0;
  right: 0;
  height: 6px;
  cursor: ns-resize;
}
.rz-south {
  bottom: 0;
  left: 0;
  right: 0;
  height: 6px;
  cursor: ns-resize;
}
.rz-east {
  top: 0;
  bottom: 0;
  right: 0;
  width: 6px;
  cursor: ew-resize;
}
.rz-west {
  top: 0;
  bottom: 0;
  left: 0;
  width: 6px;
  cursor: ew-resize;
}
.rz-northeast {
  top: 0;
  right: 0;
  width: 14px;
  height: 14px;
  cursor: nesw-resize;
}
.rz-southwest {
  bottom: 0;
  left: 0;
  width: 14px;
  height: 14px;
  cursor: nesw-resize;
}
.rz-northwest {
  top: 0;
  left: 0;
  width: 14px;
  height: 14px;
  cursor: nwse-resize;
}
.rz-southeast {
  bottom: 0;
  right: 0;
  width: 14px;
  height: 14px;
  cursor: nwse-resize;
}
.tf-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
  margin-bottom: 8px;
  cursor: move;
}
.tf-header.locked { cursor: default; }
.tf-title {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.8125em;
  font-weight: 600;
  color: var(--text-1);
  letter-spacing: -0.01em;
  margin: 0;
}
.tf-title :deep(svg) {
  color: var(--brand-500);
}
.tf-controls {
  display: flex;
  gap: 2px;
}
.tf-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  border: none;
  background: transparent;
  border-radius: 6px;
  color: var(--text-3);
  cursor: pointer;
  transition: background 0.15s, color 0.15s;
}
.tf-btn:hover {
  background: var(--bg-card-soft);
  color: var(--text-1);
}
.tf-btn.active {
  color: var(--brand-500);
}
.tf-btn.tf-close:hover {
  background: var(--window-close);
  color: var(--text-on-accent);
}
.tf-add {
  flex-shrink: 0;
  margin-bottom: 8px;
}
.tf-input {
  width: 100%;
  border: 1px solid var(--border-soft);
  border-radius: var(--radius-md);
  background: var(--input-bg);
  color: var(--text-1);
  font-size: 0.8125em;
  padding: 7px 10px;
  outline: none;
  box-sizing: border-box;
  transition: border-color 0.18s, box-shadow 0.18s;
  display: block;
  resize: none;
  line-height: 1.45;
  overflow-y: auto;
}
.tf-input:focus {
  border-color: var(--brand-500);
  box-shadow: var(--shadow-focus);
}
.tf-input::placeholder {
  color: var(--text-4);
}
.tf-section-label { padding: 4px 4px 2px; font-size: .7em; color: var(--text-4); letter-spacing: .04em; }
.tf-list { display: flex; flex-direction: column; gap: 2px; }
.tf-body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  margin: 0 -4px;
  padding: 0 4px;
}
.tf-empty {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-4);
}
.tf-empty p {
  margin: 0;
  font-size: 0.8125em;
}
</style>
