#requires -Version 7
<#
Build x-hub as a portable Windows x64 ZIP.
Requirements: Node.js 24, npm, Rust stable toolchain, Windows build tools, and WebView2 on the target PC.
Output: dist-portable/x-hub-<version>-win-x64-portable.zip
The portable marker makes every application data file use <exe-dir>\data.
#>
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Push-Location $root
try {
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw '未找到 Node.js；请安装 Node.js 24。' }
  $major = [int]((node -p "process.versions.node.split('.')[0]").Trim())
  if ($major -lt 24) { throw "需要 Node.js 24 或更高版本，当前为 $major。" }
  npm ci
  if ($LASTEXITCODE -ne 0) { throw 'npm ci 失败。' }
  npm run tauri:build -- --no-bundle
  if ($LASTEXITCODE -ne 0) { throw 'Tauri 构建失败。' }
  $exe = Join-Path $root 'src-tauri/target/release/x-hub.exe'
  if (-not (Test-Path -LiteralPath $exe)) { throw "构建产物不存在：$exe" }
  $version = (Get-Content (Join-Path $root 'package.json') -Raw | ConvertFrom-Json).version
  $outDir = Join-Path $root 'dist-portable'
  if (Test-Path $outDir) { Remove-Item $outDir -Recurse -Force }
  $stage = Join-Path $outDir 'x-hub-portable'
  New-Item -ItemType Directory -Force -Path (Join-Path $stage 'data') | Out-Null
  Copy-Item -LiteralPath $exe -Destination (Join-Path $stage 'x-hub.exe')
  New-Item -ItemType File -Force -Path (Join-Path $stage 'portable') | Out-Null
  @'
x-hub portable data directory

All transferable application data is stored here: app.db, app.json, desktop_widgets.json,
icons, notes, wallpapers, logs, and other local application files. To migrate to another PC,
close x-hub and copy the entire folder containing x-hub.exe, portable, and data.
'@ | Set-Content -Path (Join-Path $stage 'data/README.txt') -Encoding utf8
  $zip = Join-Path $outDir "x-hub-$version-win-x64-portable.zip"
  Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal -Force
  $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
  Write-Host "便携版已生成：$zip" -ForegroundColor Green
  Write-Host "SHA-256: $hash"
  Write-Host '目录结构：x-hub.exe + portable + data\'
} finally { Pop-Location }
